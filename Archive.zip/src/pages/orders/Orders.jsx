import { useState, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import {
  fetchSSList,
  fetchDistributorsBySS,
  fetchShopsByDistributor,
  fetchAllDistributors,
  fetchAllShops,
  fetchCategories,
  createOrder,
  createEntity,
  clearSuccessMessage,
  clearError,
} from '../../store/slices/ordersSlice'
import { Button } from '../../components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card'
import { Input } from '../../components/ui/input'
import { Label } from '../../components/ui/label'
import { Select } from '../../components/ui/select'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '../../components/ui/dialog'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../components/ui/tabs'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../../components/ui/table'

import { COSMETICS_CATEGORIES, MOCK_SUPERVISOR_PROMOTERS, MOCK_PRODUCTS, getProductsByCategory, MOCK_SHOP_STOCK_AVAILABILITY, MOCK_DISTRIBUTOR_STOCK_AVAILABILITY } from '../../data/mockData'
import { Plus, Eye } from 'lucide-react'

// Get category names for dropdown
const CATEGORIES = COSMETICS_CATEGORIES.map(cat => cat.name)

const Orders = () => {
  const dispatch = useDispatch()
  const { user } = useSelector((state) => state.auth)
  const { ssList, distributors, shops, categories, createdOrders, loading, error, successMessage } = useSelector(
    (state) => state.orders
  )

  const isSupervisor = user?.role === 'Supervisor'
  const isRSM = user?.role === 'RSM'
  const [orderType, setOrderType] = useState(isSupervisor ? 'shop' : 'ss') // Supervisor defaults to shop
  const [showRSMOrderDialog, setShowRSMOrderDialog] = useState(false)
  const [rsmOrderData, setRsmOrderData] = useState({
    entityType: 'ss', // ss, distributor, shop
    entityId: '',
    products: {}, // Structure: { productId: quantity }
  })
  const [orderData, setOrderData] = useState({
    ssId: '',
    distributorId: '',
    shopId: '',
    categories: {},
    // Supervisor-specific fields
    promoterId: '', // For Supervisor: Select Promoter
    primaryOrder: '', // Primary order details
    secondaryOrder: '', // Secondary order details
    shopTarget: '', // Target for shop
    shopStockVolume: '', // Shop Stock Volume
    distributorAvlStock: '', // Distributor Available Stock
    display: '', // Display information
    purchaseValue: 0, // Calculated Purchase Value (Day)
  })
  const [showEntityDialog, setShowEntityDialog] = useState(false)
  const [entityType, setEntityType] = useState('ss')
  const [entityData, setEntityData] = useState({})
  const [showSupervisorOrderDialog, setShowSupervisorOrderDialog] = useState(false)
  const [supervisorOrderData, setSupervisorOrderData] = useState({
    shopId: '',
    distributorId: '',
    products: {}, // Structure: { productId: quantity }
    shopStockAvailability: '', // Shop Stock Availability
    distributorStockAvailability: '', // Distributor Stock Availability
  })
  const [showOrderViewDialog, setShowOrderViewDialog] = useState(false)
  const [selectedOrder, setSelectedOrder] = useState(null)

  useEffect(() => {
    dispatch(fetchSSList())
    dispatch(fetchCategories())
    dispatch(fetchAllDistributors())
    dispatch(fetchAllShops())
  }, [dispatch])

  // Reset form when switching order types (only for non-Supervisor)
  useEffect(() => {
    if (!isSupervisor) {
      setOrderData(prev => ({
        ...prev,
        ssId: '',
        distributorId: '',
        shopId: '',
        categories: {},
      }))
    }
  }, [orderType, isSupervisor])

  const handleOrderSubmit = async (e) => {
    e.preventDefault()
    
    // Supervisor-specific validation
    if (isSupervisor) {
      if (!orderData.promoterId || !orderData.shopId) {
        alert('Please select Promoter and Shop')
        return
      }
    }
    
    // Get entity name based on order type
    let entityName = ''
    if (orderType === 'ss') {
      const ss = ssList.find(s => s.id === parseInt(orderData.ssId))
      entityName = ss?.name || 'Unknown SS'
    } else if (orderType === 'distributor') {
      const dist = distributors.find(d => d.id === parseInt(orderData.distributorId))
      entityName = dist?.name || 'Unknown Distributor'
    } else if (orderType === 'shop') {
      const shop = shops.find(s => s.id === parseInt(orderData.shopId))
      entityName = shop?.name || 'Unknown Shop'
    }
    
    // For Supervisor, get promoter name
    if (isSupervisor && orderData.promoterId) {
      const promoter = MOCK_SUPERVISOR_PROMOTERS.find(p => p.id === parseInt(orderData.promoterId))
      entityName = promoter ? `${entityName} (via ${promoter.name})` : entityName
    }
    
    const submitData = {
      orderType: isSupervisor ? 'shop' : orderType,
      entityName,
      ...orderData,
    }
    
    const result = await dispatch(createOrder(submitData))
    
    if (createOrder.fulfilled.match(result)) {
      // Reset form
      setOrderData({
        ssId: '',
        distributorId: '',
        shopId: '',
        categories: {},
        promoterId: '',
        primaryOrder: '',
        secondaryOrder: '',
        shopTarget: '',
        shopStockVolume: '',
        distributorAvlStock: '',
        display: '',
        purchaseValue: 0,
      })
      // Clear success message after 5 seconds
      setTimeout(() => {
        dispatch(clearSuccessMessage())
      }, 5000)
    }
  }

  const getEntityName = (order) => {
    // For Supervisor orders, show shop and distributor
    if (isSupervisor && order.shopId) {
      const shop = shops.find(s => s.id === parseInt(order.shopId))
      const distributor = distributors.find(d => d.id === parseInt(order.distributorId))
      if (shop && distributor) {
        return `${shop.name} (Distributor: ${distributor.name})`
      }
      return shop?.name || 'Unknown Shop'
    }
    
    if (order.orderType === 'ss') {
      const ss = ssList.find(s => s.id === parseInt(order.ssId))
      return ss?.name || 'Unknown SS'
    } else if (order.orderType === 'distributor') {
      const dist = distributors.find(d => d.id === parseInt(order.distributorId))
      return dist?.name || 'Unknown Distributor'
    } else if (order.orderType === 'shop') {
      const shop = shops.find(s => s.id === parseInt(order.shopId))
      return shop?.name || 'Unknown Shop'
    }
    return 'Unknown'
  }

  const handleCategoryChange = (category, value) => {
    const newCategories = {
      ...orderData.categories,
      [category]: value,
    }
    
    // Calculate Purchase Value for Supervisor (sum of all category cases * average price per case)
    let purchaseValue = 0
    if (isSupervisor) {
      const averagePricePerCase = 5000 // Mock average price per case
      Object.values(newCategories).forEach(cases => {
        purchaseValue += (parseInt(cases) || 0) * averagePricePerCase
      })
    }
    
    setOrderData({
      ...orderData,
      categories: newCategories,
      purchaseValue: isSupervisor ? purchaseValue : orderData.purchaseValue,
    })
  }

  // Supervisor-specific product quantity handler with series (3, 6, 12, 18)
  const handleSupervisorProductQuantity = (productId, quantity) => {
    setSupervisorOrderData({
      ...supervisorOrderData,
      products: {
        ...supervisorOrderData.products,
        [productId]: quantity,
      },
    })
  }

  // Handle quantity increment/decrement by 3
  const handleQuantityChange = (productId, currentValue, direction) => {
    const currentQty = parseInt(currentValue) || 0
    
    if (direction === 'increment') {
      // Increment by 3
      const nextValue = currentQty + 3
      handleSupervisorProductQuantity(productId, nextValue.toString())
    } else if (direction === 'decrement') {
      // Decrement by 3, but don't go below 0
      const prevValue = Math.max(0, currentQty - 3)
      handleSupervisorProductQuantity(productId, prevValue > 0 ? prevValue.toString() : '')
    }
  }

  // Handle RSM product quantity
  const handleRSMProductQuantity = (productId, quantity) => {
    setRsmOrderData({
      ...rsmOrderData,
      products: {
        ...rsmOrderData.products,
        [productId]: quantity,
      },
    })
  }

  // Handle RSM quantity increment/decrement
  const handleRSMQuantityChange = (productId, currentValue, direction) => {
    const currentQty = parseInt(currentValue) || 0
    
    if (direction === 'increment') {
      const nextValue = currentQty + 1
      handleRSMProductQuantity(productId, nextValue.toString())
    } else if (direction === 'decrement') {
      const prevValue = Math.max(0, currentQty - 1)
      handleRSMProductQuantity(productId, prevValue > 0 ? prevValue.toString() : '')
    }
  }

  // Handle RSM order submission
  const handleRSMOrderSubmit = async (e) => {
    e.preventDefault()
    
    if (!rsmOrderData.entityId) {
      alert(`Please select ${rsmOrderData.entityType === 'ss' ? 'SS' : rsmOrderData.entityType === 'distributor' ? 'Distributor' : 'Shop'}`)
      return
    }

    // Check if at least one product has quantity
    const hasProducts = Object.values(rsmOrderData.products).some(qty => parseInt(qty) > 0)
    if (!hasProducts) {
      alert('Please add at least one product with quantity')
      return
    }

    // Get entity name
    let entityName = ''
    if (rsmOrderData.entityType === 'ss') {
      const ss = ssList.find(s => s.id === parseInt(rsmOrderData.entityId))
      entityName = ss?.name || 'Unknown SS'
    } else if (rsmOrderData.entityType === 'distributor') {
      const dist = distributors.find(d => d.id === parseInt(rsmOrderData.entityId))
      entityName = dist?.name || 'Unknown Distributor'
    } else if (rsmOrderData.entityType === 'shop') {
      const shop = shops.find(s => s.id === parseInt(rsmOrderData.entityId))
      entityName = shop?.name || 'Unknown Shop'
    }
    
    const submitData = {
      orderType: rsmOrderData.entityType,
      entityName,
      [rsmOrderData.entityType === 'ss' ? 'ssId' : rsmOrderData.entityType === 'distributor' ? 'distributorId' : 'shopId']: rsmOrderData.entityId,
      products: rsmOrderData.products,
    }
    
    const result = await dispatch(createOrder(submitData))
    
    if (createOrder.fulfilled.match(result)) {
      // Reset form
      setRsmOrderData({
        entityType: 'ss',
        entityId: '',
        products: {},
      })
      setShowRSMOrderDialog(false)
      // Clear success message after 5 seconds
      setTimeout(() => {
        dispatch(clearSuccessMessage())
      }, 5000)
    }
  }

  // Handle Supervisor order submission
  const handleSupervisorOrderSubmit = async (e) => {
    e.preventDefault()
    
    if (!supervisorOrderData.shopId || !supervisorOrderData.distributorId) {
      alert('Please select Shop and Distributor')
      return
    }

    const shop = shops.find(s => s.id === parseInt(supervisorOrderData.shopId))
    const distributor = distributors.find(d => d.id === parseInt(supervisorOrderData.distributorId))
    
    const submitData = {
      orderType: 'shop',
      entityName: shop?.name || 'Unknown Shop',
      shopId: supervisorOrderData.shopId,
      shopName: shop?.name,
      distributorId: supervisorOrderData.distributorId,
      distributorName: distributor?.name,
      products: supervisorOrderData.products,
    }
    
    const result = await dispatch(createOrder(submitData))
    
    if (createOrder.fulfilled.match(result)) {
      // Reset form
      setSupervisorOrderData({
        shopId: '',
        distributorId: '',
        products: {},
        shopStockAvailability: '',
        distributorStockAvailability: '',
      })
      setShowSupervisorOrderDialog(false)
      // Clear success message after 5 seconds
      setTimeout(() => {
        dispatch(clearSuccessMessage())
      }, 5000)
    }
  }

  const handleEntitySubmit = async () => {
    await dispatch(createEntity({ type: entityType, data: entityData }))
    setShowEntityDialog(false)
    setEntityData({})
  }

  return (
    <div className="space-y-6">
      {/* Header with Create Order Button */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">
            {isSupervisor ? 'Orders' : 'Orders & Entity Creation'}
          </h1>
          <p className="text-gray-600 mt-2">
            {isSupervisor 
              ? 'View and create orders' 
              : 'Create orders and manage entities'
            }
          </p>
        </div>
        {(isRSM || isSupervisor) && (
          <Button
            onClick={() => isSupervisor ? setShowSupervisorOrderDialog(true) : setShowRSMOrderDialog(true)}
            className="bg-[#433228] hover:bg-[#5a4238] text-white"
          >
            <Plus className="h-4 w-4 mr-2" />
            Create Order
          </Button>
        )}
      </div>

      <Tabs defaultValue={isSupervisor ? "orders" : "orders"} className="w-full">
        <TabsList>
          {isSupervisor ? (
            <>
              <TabsTrigger value="orders">Orders</TabsTrigger>
              <TabsTrigger value="stock-availability">Stock Availability</TabsTrigger>
            </>
          ) : (
            <>
              <TabsTrigger value="orders">Orders</TabsTrigger>
              <TabsTrigger value="entities">Entities</TabsTrigger>
            </>
          )}
        </TabsList>

        {/* Supervisor Orders Tab */}
        {isSupervisor && (
          <TabsContent value="orders">
            {/* Success Message */}
            {successMessage && (
              <Card className="border-green-500 bg-green-50 mb-6">
                <CardContent className="pt-6">
                  <p className="text-green-700 font-medium">{successMessage}</p>
                </CardContent>
              </Card>
            )}

            {/* Error Message */}
            {error && (
              <Card className="border-destructive mb-6">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <p className="text-destructive">{error}</p>
                    <Button variant="ghost" size="sm" onClick={() => dispatch(clearError())}>
                      ×
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Orders List Table */}
            <Card>
              <CardHeader>
                <CardTitle>Orders</CardTitle>
                <CardDescription>List of all submitted orders</CardDescription>
              </CardHeader>
              <CardContent>
                {createdOrders.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>S.No</TableHead>
                        <TableHead>Order ID</TableHead>
                        <TableHead>Batch ID</TableHead>
                        <TableHead className="text-right">Total Value</TableHead>
                        <TableHead>Order Date</TableHead>
                        <TableHead className="text-center">View</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {createdOrders.map((order, index) => {
                        // Calculate total value
                        const totalValue = order.products && Object.keys(order.products).length > 0
                          ? Object.entries(order.products).reduce((sum, [productId, quantity]) => {
                              const product = MOCK_PRODUCTS.find(p => p.id === parseInt(productId))
                              return sum + (parseInt(quantity) * (product?.price || 0))
                            }, 0)
                          : 0

                        return (
                          <TableRow key={order.id}>
                            <TableCell className="font-medium">{index + 1}</TableCell>
                            <TableCell className="font-medium">{order.orderId || `ORD-${order.id}`}</TableCell>
                            <TableCell>{order.batchId || `BATCH-${order.id}`}</TableCell>
                            <TableCell className="text-right">
                              <span className="font-semibold text-green-600">
                                ₹{totalValue.toLocaleString('en-IN')}
                              </span>
                            </TableCell>
                            <TableCell>
                              {order.createdAt ? new Date(order.createdAt).toLocaleDateString() : 'Just now'}
                            </TableCell>
                            <TableCell className="text-center">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => {
                                  setSelectedOrder(order)
                                  setShowOrderViewDialog(true)
                                }}
                              >
                                <Eye className="h-4 w-4 mr-1" />
                                View
                              </Button>
                            </TableCell>
                          </TableRow>
                        )
                      })}
                    </TableBody>
                  </Table>
                ) : (
                  <p className="text-center text-gray-500 py-8">No orders created yet</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        )}

        {/* Supervisor Stock Availability Tab */}
        {isSupervisor && (
          <TabsContent value="stock-availability">
            <div className="space-y-6">
              {/* Shop Stock Availability by Category */}
              <Card>
                <CardHeader>
                  <CardTitle>Shop Stock Availability</CardTitle>
                  <CardDescription>Current stock availability by category and products at all shops</CardDescription>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue={COSMETICS_CATEGORIES[0]?.name} className="w-full">
                    <TabsList className="grid w-full grid-cols-4">
                      {COSMETICS_CATEGORIES.map((category) => (
                        <TabsTrigger key={category.id} value={category.name}>
                          {category.name}
                        </TabsTrigger>
                      ))}
                    </TabsList>

                    {COSMETICS_CATEGORIES.map((category) => {
                      const categoryProducts = getProductsByCategory(category.name)
                      return (
                        <TabsContent key={category.id} value={category.name} className="space-y-4 mt-4">
                          <div className="border rounded-lg p-4">
                            <h3 className="text-lg font-semibold text-[#433228] mb-4">{category.name} - Shop Stock</h3>
                            <Table>
                              <TableHeader>
                                <TableRow>
                                  <TableHead>Shop Name</TableHead>
                                  <TableHead>Distributor</TableHead>
                                  {categoryProducts.map((product) => (
                                    <TableHead key={product.id} className="text-center">
                                      {product.name}
                                    </TableHead>
                                  ))}
                                  <TableHead className="text-right">Category Total</TableHead>
                                </TableRow>
                              </TableHeader>
                              <TableBody>
                                {MOCK_SHOP_STOCK_AVAILABILITY.map((shop) => {
                                  // Calculate stock per product (mock calculation - distribute total stock across products)
                                  const productsStock = categoryProducts.map((product) => {
                                    // Mock: Distribute stock evenly across products in category
                                    const stockPerProduct = Math.floor(shop.totalStock / 16) // 16 total products across all categories
                                    return {
                                      productId: product.id,
                                      stock: stockPerProduct + (Math.random() * 50) // Add some variation
                                    }
                                  })
                                  const categoryTotal = productsStock.reduce((sum, p) => sum + Math.floor(p.stock), 0)

                                  return (
                                    <TableRow key={shop.id}>
                                      <TableCell className="font-medium">{shop.shopName}</TableCell>
                                      <TableCell>{shop.distributorName}</TableCell>
                                      {productsStock.map((productStock) => (
                                        <TableCell key={productStock.productId} className="text-center">
                                          <span className="font-semibold text-blue-600">
                                            {Math.floor(productStock.stock)}
                                          </span>
                                        </TableCell>
                                      ))}
                                      <TableCell className="text-right">
                                        <span className="font-semibold text-green-600">
                                          {categoryTotal}
                                        </span>
                                      </TableCell>
                                    </TableRow>
                                  )
                                })}
                              </TableBody>
                            </Table>
                          </div>
                        </TabsContent>
                      )
                    })}
                  </Tabs>
                </CardContent>
              </Card>

              {/* Distributor Stock Availability by Category */}
              <Card>
                <CardHeader>
                  <CardTitle>Distributor Stock Availability</CardTitle>
                  <CardDescription>Current stock availability by category and products at all distributors</CardDescription>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue={COSMETICS_CATEGORIES[0]?.name} className="w-full">
                    <TabsList className="grid w-full grid-cols-4">
                      {COSMETICS_CATEGORIES.map((category) => (
                        <TabsTrigger key={category.id} value={category.name}>
                          {category.name}
                        </TabsTrigger>
                      ))}
                    </TabsList>

                    {COSMETICS_CATEGORIES.map((category) => {
                      const categoryProducts = getProductsByCategory(category.name)
                      return (
                        <TabsContent key={category.id} value={category.name} className="space-y-4 mt-4">
                          <div className="border rounded-lg p-4">
                            <h3 className="text-lg font-semibold text-[#433228] mb-4">{category.name} - Distributor Stock</h3>
                            <Table>
                              <TableHeader>
                                <TableRow>
                                  <TableHead>Distributor Name</TableHead>
                                  <TableHead>Code</TableHead>
                                  {categoryProducts.map((product) => (
                                    <TableHead key={product.id} className="text-center">
                                      {product.name}
                                    </TableHead>
                                  ))}
                                  <TableHead className="text-right">Available</TableHead>
                                  <TableHead className="text-right">Category Total</TableHead>
                                </TableRow>
                              </TableHeader>
                              <TableBody>
                                {MOCK_DISTRIBUTOR_STOCK_AVAILABILITY.map((distributor) => {
                                  // Calculate stock per product (mock calculation)
                                  const productsStock = categoryProducts.map((product) => {
                                    // Mock: Distribute available stock across products
                                    const stockPerProduct = Math.floor(distributor.availableStock / 16)
                                    return {
                                      productId: product.id,
                                      available: stockPerProduct + (Math.random() * 100)
                                    }
                                  })
                                  const categoryAvailable = productsStock.reduce((sum, p) => sum + Math.floor(p.available), 0)
                                  const categoryTotal = categoryAvailable

                                  return (
                                    <TableRow key={distributor.id}>
                                      <TableCell className="font-medium">{distributor.distributorName}</TableCell>
                                      <TableCell>{distributor.code}</TableCell>
                                      {productsStock.map((productStock) => (
                                        <TableCell key={productStock.productId} className="text-center">
                                          <span className="font-semibold text-green-600">
                                            {Math.floor(productStock.available)}
                                          </span>
                                        </TableCell>
                                      ))}
                                      <TableCell className="text-right">
                                        <span className="font-semibold text-green-600">
                                          {categoryAvailable.toLocaleString('en-IN')}
                                        </span>
                                      </TableCell>
                                      <TableCell className="text-right">
                                        <span className="font-semibold">
                                          {categoryTotal.toLocaleString('en-IN')}
                                        </span>
                                      </TableCell>
                                    </TableRow>
                                  )
                                })}
                              </TableBody>
                            </Table>
                          </div>
                        </TabsContent>
                      )
                    })}
                  </Tabs>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        )}

        {/* RSM/ASM/SO Orders Tab */}
        {!isSupervisor && (
          <TabsContent value="orders">
            {/* Orders List - Always shown for RSM */}
            {(isRSM || createdOrders.length > 0) && (
              <Card className={isRSM ? '' : 'mb-6'}>
                <CardHeader>
                  <CardTitle>Created Orders</CardTitle>
                  <CardDescription>List of all submitted orders</CardDescription>
                </CardHeader>
                <CardContent>
                  {createdOrders.length > 0 ? (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>S.No</TableHead>
                          <TableHead>Order ID</TableHead>
                          <TableHead>Batch ID</TableHead>
                          <TableHead className="text-right">Overall Value</TableHead>
                          <TableHead className="text-center">View</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {createdOrders.map((order, index) => {
                          // Calculate overall value
                          const overallValue = order.products && Object.keys(order.products).length > 0
                            ? Object.entries(order.products).reduce((sum, [productId, quantity]) => {
                                const product = MOCK_PRODUCTS.find(p => p.id === parseInt(productId))
                                return sum + (parseInt(quantity) * (product?.price || 0))
                              }, 0)
                            : 0

                          return (
                            <TableRow key={order.id}>
                              <TableCell className="font-medium">{index + 1}</TableCell>
                              <TableCell className="font-medium">{order.orderId || `ORD-${order.id}`}</TableCell>
                              <TableCell>{order.batchId || `BATCH-${order.id}`}</TableCell>
                              <TableCell className="text-right">
                                <span className="font-semibold text-green-600">
                                  ₹{overallValue.toLocaleString('en-IN')}
                                </span>
                              </TableCell>
                              <TableCell className="text-center">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => {
                                    setSelectedOrder(order)
                                    setShowOrderViewDialog(true)
                                  }}
                                >
                                  <Eye className="h-4 w-4 mr-1" />
                                  View
                                </Button>
                              </TableCell>
                            </TableRow>
                          )
                        })}
                      </TableBody>
                    </Table>
                  ) : (
                    <p className="text-center text-gray-500 py-8">No orders created yet</p>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Order Creation Form - Only for non-RSM */}
            {!isRSM && (
              <>
              <Card>
                <CardHeader>
                  <CardTitle>Create New Order</CardTitle>
                  <CardDescription>Select order type and enter category-wise cases</CardDescription>
                </CardHeader>
                <CardContent>
                  <Tabs value={orderType} onValueChange={setOrderType} className="w-full">
                    <TabsList className="grid w-full grid-cols-3">
                      <TabsTrigger value="ss">SS Order</TabsTrigger>
                      <TabsTrigger value="distributor">Distributor Order</TabsTrigger>
                      <TabsTrigger value="shop">Shop Order</TabsTrigger>
                    </TabsList>

                {/* SS Order Tab */}
                <TabsContent value="ss">
                  <form onSubmit={handleOrderSubmit} className="space-y-6 mt-6">
                    <div className="space-y-2">
                      <Label>Super Stockist (SS)</Label>
                      <Select
                        value={orderData.ssId}
                        onChange={(e) =>
                          setOrderData({
                            ...orderData,
                            ssId: e.target.value,
                            distributorId: '',
                            shopId: '',
                          })
                        }
                        required
                      >
                        <option value="">Select SS</option>
                        {ssList.map((ss) => (
                          <option key={ss.id} value={ss.id}>
                            {ss.name}
                          </option>
                        ))}
                      </Select>
                    </div>

                    <div className="space-y-4">
                      <Label className="text-lg font-semibold">Category-wise Cases</Label>
                      <div className="border rounded-lg p-4 space-y-4">
                        {CATEGORIES.map((category) => (
                          <div key={category} className="flex items-center gap-4">
                            <Label className="w-40 font-medium">{category}</Label>
                            <Input
                              type="number"
                              placeholder="Enter cases"
                              value={orderData.categories[category] || ''}
                              onChange={(e) => {
                                const value = e.target.value === '' ? '' : Math.max(0, parseInt(e.target.value) || 0)
                                handleCategoryChange(category, value)
                              }}
                              onInput={(e) => {
                                if (e.target.value < 0) e.target.value = 0
                              }}
                              min="0"
                              className="max-w-xs"
                            />
                            <span className="text-sm text-gray-500">cases</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {error && (
                      <div className="text-sm text-destructive bg-destructive/10 p-3 rounded-md">
                        {error}
                      </div>
                    )}

                    <Button type="submit" className="w-full" disabled={loading}>
                      {loading ? 'Submitting...' : 'Submit SS Order'}
                    </Button>
                  </form>
                </TabsContent>

                {/* Distributor Order Tab */}
                <TabsContent value="distributor">
                  <form onSubmit={handleOrderSubmit} className="space-y-6 mt-6">
                    <div className="space-y-2">
                      <Label>Distributor</Label>
                      <Select
                        value={orderData.distributorId}
                        onChange={(e) =>
                          setOrderData({
                            ...orderData,
                            distributorId: e.target.value,
                            shopId: '',
                          })
                        }
                        required
                      >
                        <option value="">Select Distributor</option>
                        {distributors.map((dist) => (
                          <option key={dist.id} value={dist.id}>
                            {dist.name}
                          </option>
                        ))}
                      </Select>
                    </div>

                    <div className="space-y-4">
                      <Label className="text-lg font-semibold">Category-wise Cases</Label>
                      <div className="border rounded-lg p-4 space-y-4">
                        {CATEGORIES.map((category) => (
                          <div key={category} className="flex items-center gap-4">
                            <Label className="w-40 font-medium">{category}</Label>
                            <Input
                              type="number"
                              placeholder="Enter cases"
                              value={orderData.categories[category] || ''}
                              onChange={(e) => {
                                const value = e.target.value === '' ? '' : Math.max(0, parseInt(e.target.value) || 0)
                                handleCategoryChange(category, value)
                              }}
                              onInput={(e) => {
                                if (e.target.value < 0) e.target.value = 0
                              }}
                              min="0"
                              className="max-w-xs"
                            />
                            <span className="text-sm text-gray-500">cases</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {error && (
                      <div className="text-sm text-destructive bg-destructive/10 p-3 rounded-md">
                        {error}
                      </div>
                    )}

                    <Button type="submit" className="w-full" disabled={loading}>
                      {loading ? 'Submitting...' : 'Submit Distributor Order'}
                    </Button>
                  </form>
                </TabsContent>

                {/* Shop Order Tab */}
                <TabsContent value="shop">
                  <form onSubmit={handleOrderSubmit} className="space-y-6 mt-6">
                    <div className="space-y-2">
                      <Label>Shop</Label>
                      <Select
                        value={orderData.shopId}
                        onChange={(e) =>
                          setOrderData({ ...orderData, shopId: e.target.value })
                        }
                        required
                      >
                        <option value="">Select Shop</option>
                        {shops.map((shop) => (
                          <option key={shop.id} value={shop.id}>
                            {shop.name}
                          </option>
                        ))}
                      </Select>
                    </div>

                    <div className="space-y-4">
                      <Label className="text-lg font-semibold">Category-wise Cases</Label>
                      <div className="border rounded-lg p-4 space-y-4">
                        {CATEGORIES.map((category) => (
                          <div key={category} className="flex items-center gap-4">
                            <Label className="w-40 font-medium">{category}</Label>
                            <Input
                              type="number"
                              placeholder="Enter cases"
                              value={orderData.categories[category] || ''}
                              onChange={(e) => {
                                const value = e.target.value === '' ? '' : Math.max(0, parseInt(e.target.value) || 0)
                                handleCategoryChange(category, value)
                              }}
                              onInput={(e) => {
                                if (e.target.value < 0) e.target.value = 0
                              }}
                              min="0"
                              className="max-w-xs"
                            />
                            <span className="text-sm text-gray-500">cases</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {error && (
                      <div className="text-sm text-destructive bg-destructive/10 p-3 rounded-md">
                        {error}
                      </div>
                    )}

                    <Button type="submit" className="w-full" disabled={loading}>
                      {loading ? 'Submitting...' : 'Submit Shop Order'}
                    </Button>
                  </form>
                </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>

              {/* Success Message */}
              {successMessage && (
                <Card className="border-green-500 bg-green-50 mt-6">
                  <CardContent className="pt-6">
                    <p className="text-green-700 font-medium">{successMessage}</p>
                  </CardContent>
                </Card>
              )}

              {/* Error Message */}
              {error && (
                <Card className="border-destructive mt-6">
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <p className="text-destructive">{error}</p>
                      <Button variant="ghost" size="sm" onClick={() => dispatch(clearError())}>
                        ×
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Created Orders List - Only for non-RSM (RSM orders shown above) */}
              {createdOrders.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Created Orders</CardTitle>
                <CardDescription>List of all submitted orders</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {createdOrders.map((order) => (
                    <div key={order.id} className="border rounded-lg p-4">
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <h4 className="font-semibold">{getEntityName(order)}</h4>
                          <p className="text-sm text-gray-600">
                            Type: {order.orderType?.toUpperCase() || 'N/A'} | 
                            Created: {order.createdAt ? new Date(order.createdAt).toLocaleString() : 'Just now'}
                          </p>
                        </div>
                        <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs">
                          {order.status || 'Pending'}
                        </span>
                      </div>
                      
                      {/* Supervisor-specific order details */}
                      {isSupervisor && order.shopId && (
                        <div className="mt-3 mb-3 p-3 bg-gray-50 rounded-lg">
                          <h5 className="font-medium text-sm mb-2">Order Details:</h5>
                          <div className="grid grid-cols-2 gap-2 text-sm">
                            {order.shopName && (
                              <div className="flex justify-between">
                                <span className="text-gray-600">Shop:</span>
                                <span className="font-medium">{order.shopName}</span>
                              </div>
                            )}
                            {order.distributorName && (
                              <div className="flex justify-between">
                                <span className="text-gray-600">Distributor:</span>
                                <span className="font-medium">{order.distributorName}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                      
                      {/* Product-wise details for Supervisor orders */}
                      {isSupervisor && order.products && Object.keys(order.products).length > 0 ? (
                        <div className="mt-3">
                          <h5 className="font-medium text-sm mb-2">Product-wise Quantity:</h5>
                          <div className="space-y-3">
                            {Object.entries(order.products).map(([productId, quantity]) => {
                              const product = MOCK_PRODUCTS.find(p => p.id === parseInt(productId))
                              if (!product || !quantity) return null
                              const totalPrice = parseInt(quantity) * product.price
                              return (
                                <div key={productId} className="border rounded-lg p-3 bg-white">
                                  <div className="flex justify-between items-start mb-2">
                                    <div>
                                      <p className="font-medium text-sm">{product.name}</p>
                                      <p className="text-xs text-gray-500">Code: {product.code} | Price: ₹{product.price}/{product.unit}</p>
                                    </div>
                                    <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs font-medium">
                                      {quantity} units
                                    </span>
                                  </div>
                                  <div className="flex justify-between text-sm mt-2 pt-2 border-t">
                                    <span className="text-gray-600">Total Value:</span>
                                    <span className="font-semibold text-green-600">₹{totalPrice.toLocaleString('en-IN')}</span>
                                  </div>
                                </div>
                              )
                            })}
                          </div>
                          {/* Calculate and display total order value */}
                          {(() => {
                            const totalOrderValue = Object.entries(order.products).reduce((sum, [productId, quantity]) => {
                              const product = MOCK_PRODUCTS.find(p => p.id === parseInt(productId))
                              return sum + (parseInt(quantity) * (product?.price || 0))
                            }, 0)
                            return totalOrderValue > 0 ? (
                              <div className="mt-4 p-3 bg-green-50 rounded-lg border-2 border-green-200">
                                <div className="flex justify-between items-center">
                                  <span className="font-semibold text-green-800">Total Order Value:</span>
                                  <span className="text-xl font-bold text-green-700">₹{totalOrderValue.toLocaleString('en-IN')}</span>
                                </div>
                              </div>
                            ) : null
                          })()}
                        </div>
                      ) : (
                        /* Category-wise details for non-Supervisor orders */
                        <div className="mt-3">
                          <h5 className="font-medium text-sm mb-2">Category-wise Cases:</h5>
                          <div className="grid grid-cols-2 gap-2 text-sm">
                            {Object.entries(order.categories || {}).map(([category, cases]) => (
                              cases ? (
                                <div key={category} className="flex justify-between">
                                  <span className="text-gray-600">{category}:</span>
                                  <span className="font-medium">{cases} cases</span>
                                </div>
                              ) : null
                            ))}
                          </div>
                          {Object.keys(order.categories || {}).filter(cat => order.categories[cat]).length === 0 && (
                            <p className="text-gray-400 text-sm">No categories selected</p>
                          )}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
                </CardContent>
              </Card>
              )}
              </>
            )}
        </TabsContent>
        )}

        {/* RSM/ASM/SO Entities Tab */}
        {!isSupervisor && (
          <TabsContent value="entities">
          <Card>
            <CardHeader>
              <CardTitle>Create New Entity</CardTitle>
              <CardDescription>Create SS, Distributor, or Shop</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Entity Type</Label>
                <Select
                  value={entityType}
                  onChange={(e) => {
                    setEntityType(e.target.value)
                    setEntityData({})
                  }}
                >
                  <option value="ss">Super Stockist (SS)</option>
                  <option value="distributor">Distributor</option>
                  <option value="shop">Shop</option>
                </Select>
              </div>

              <Button onClick={() => setShowEntityDialog(true)} className="w-full">
                Open {entityType.toUpperCase()} Form
              </Button>
            </CardContent>
          </Card>
          </TabsContent>
        )}
      </Tabs>

      <Dialog open={showEntityDialog} onOpenChange={setShowEntityDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create {entityType.toUpperCase()}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {entityType === 'ss' && (
              <>
                <div className="space-y-2">
                  <Label>SS Name</Label>
                  <Input
                    value={entityData.name || ''}
                    onChange={(e) => setEntityData({ ...entityData, name: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Contact</Label>
                  <Input
                    value={entityData.contact || ''}
                    onChange={(e) => setEntityData({ ...entityData, contact: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Address</Label>
                  <Input
                    value={entityData.address || ''}
                    onChange={(e) => setEntityData({ ...entityData, address: e.target.value })}
                  />
                </div>
              </>
            )}
            {entityType === 'distributor' && (
              <>
                <div className="space-y-2">
                  <Label>Distributor Name</Label>
                  <Input
                    value={entityData.name || ''}
                    onChange={(e) => setEntityData({ ...entityData, name: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>SS</Label>
                  <Select
                    value={entityData.ssId || ''}
                    onChange={(e) => setEntityData({ ...entityData, ssId: e.target.value })}
                  >
                    <option value="">Select SS</option>
                    {ssList.map((ss) => (
                      <option key={ss.id} value={ss.id}>
                        {ss.name}
                      </option>
                    ))}
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Contact</Label>
                  <Input
                    value={entityData.contact || ''}
                    onChange={(e) => setEntityData({ ...entityData, contact: e.target.value })}
                  />
                </div>
              </>
            )}
            {entityType === 'shop' && (
              <>
                <div className="space-y-2">
                  <Label>Shop Name</Label>
                  <Input
                    value={entityData.name || ''}
                    onChange={(e) => setEntityData({ ...entityData, name: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Distributor</Label>
                  <Select
                    value={entityData.distributorId || ''}
                    onChange={(e) => setEntityData({ ...entityData, distributorId: e.target.value })}
                  >
                    <option value="">Select Distributor</option>
                    {distributors.map((dist) => (
                      <option key={dist.id} value={dist.id}>
                        {dist.name}
                      </option>
                    ))}
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Address</Label>
                  <Input
                    value={entityData.address || ''}
                    onChange={(e) => setEntityData({ ...entityData, address: e.target.value })}
                  />
                </div>
              </>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEntityDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleEntitySubmit} disabled={loading}>
              {loading ? 'Creating...' : 'Create'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Supervisor Order Creation Dialog */}
      {isSupervisor && (
        <Dialog open={showSupervisorOrderDialog} onOpenChange={setShowSupervisorOrderDialog}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create Order</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSupervisorOrderSubmit} className="space-y-6">
              {/* Step 1: Select Shop */}
              <div className="space-y-2">
                <Label>Select Shop *</Label>
                <Select
                  value={supervisorOrderData.shopId}
                  onChange={(e) => {
                    setSupervisorOrderData({
                      ...supervisorOrderData,
                      shopId: e.target.value,
                      distributorId: '', // Reset distributor when shop changes
                    })
                  }}
                  required
                >
                  <option value="">Select Shop</option>
                  {shops.map((shop) => (
                    <option key={shop.id} value={shop.id}>
                      {shop.name}
                    </option>
                  ))}
                </Select>
              </div>

              {/* Step 2: Assign Distributor to Selected Shop */}
              {supervisorOrderData.shopId && (
                <div className="space-y-2">
                  <Label>Assign Distributor to Shop *</Label>
                  <Select
                    value={supervisorOrderData.distributorId}
                    onChange={(e) => {
                      setSupervisorOrderData({
                        ...supervisorOrderData,
                        distributorId: e.target.value,
                      })
                    }}
                    required
                  >
                    <option value="">Select Distributor</option>
                    {distributors.map((distributor) => (
                      <option key={distributor.id} value={distributor.id}>
                        {distributor.name} ({distributor.code})
                      </option>
                    ))}
                  </Select>
                </div>
              )}

              {/* Step 3: Product-wise Quantity with Series (3, 6, 12, 18) */}
              {supervisorOrderData.shopId && supervisorOrderData.distributorId && (
                <div className="space-y-4 border-t pt-4">
                  <Label className="text-lg font-semibold">Product List - Assign Quantity</Label>
                  <p className="text-sm text-gray-600">Select quantity for each product using the series buttons (3, 6, 12, 18) or enter custom value</p>
                  <div className="space-y-6">
                    {COSMETICS_CATEGORIES.map((category) => {
                      const categoryProducts = getProductsByCategory(category.name)
                      return (
                        <div key={category.id} className="border rounded-lg p-4 space-y-4">
                          <Label className="text-lg font-semibold text-[#433228]">{category.name}</Label>
                          <div className="space-y-4 pl-4 border-l-2 border-gray-200">
                            {categoryProducts.map((product) => (
                              <div key={product.id} className="space-y-3 bg-gray-50 p-3 rounded-lg">
                                <div className="flex items-start gap-4">
                                  {/* Product Image */}
                                  <div className="flex-shrink-0">
                                    <img
                                      src={product.image || 'https://via.placeholder.com/100?text=Product'}
                                      alt={product.name}
                                      className="w-20 h-20 object-cover rounded-lg border border-gray-200"
                                      onError={(e) => {
                                        e.target.src = 'https://via.placeholder.com/100?text=Product'
                                      }}
                                    />
                                  </div>
                                  {/* Product Details */}
                                  <div className="flex-1">
                                    <Label className="text-base font-medium">{product.name}</Label>
                                    <p className="text-xs text-gray-500">Code: {product.code} | Price: ₹{product.price}/{product.unit}</p>
                                  </div>
                                </div>

                                {/* Quantity Input with Increment/Decrement by 3 */}
                                <div className="flex items-center gap-3">
                                  <Label className="w-32 text-sm">Quantity:</Label>
                                  <div className="flex items-center gap-1">
                                    <Button
                                      type="button"
                                      variant="outline"
                                      size="sm"
                                      onClick={() => handleQuantityChange(product.id, supervisorOrderData.products[product.id] || '0', 'decrement')}
                                      className="h-9 w-9"
                                    >
                                      -
                                    </Button>
                                    <Input
                                      type="number"
                                      min="0"
                                      step="3"
                                      placeholder="Enter quantity"
                                      value={supervisorOrderData.products[product.id] || ''}
                                      onChange={(e) => {
                                        const value = e.target.value === '' ? '' : Math.max(0, parseInt(e.target.value) || 0)
                                        handleSupervisorProductQuantity(product.id, value.toString())
                                      }}
                                      onKeyDown={(e) => {
                                        // Handle arrow keys with increment by 3
                                        if (e.key === 'ArrowUp') {
                                          e.preventDefault()
                                          handleQuantityChange(product.id, supervisorOrderData.products[product.id] || '0', 'increment')
                                        } else if (e.key === 'ArrowDown') {
                                          e.preventDefault()
                                          handleQuantityChange(product.id, supervisorOrderData.products[product.id] || '0', 'decrement')
                                        }
                                      }}
                                      onInput={(e) => {
                                        if (e.target.value < 0) e.target.value = 0
                                      }}
                                      className="max-w-xs text-center"
                                    />
                                    <Button
                                      type="button"
                                      variant="outline"
                                      size="sm"
                                      onClick={() => handleQuantityChange(product.id, supervisorOrderData.products[product.id] || '0', 'increment')}
                                      className="h-9 w-9"
                                    >
                                      +
                                    </Button>
                                  </div>
                                  <span className="text-sm text-gray-500">units (increment by 3)</span>
                                </div>

                                {/* Display Selected Quantity */}
                                {supervisorOrderData.products[product.id] && (
                                  <div className="text-sm text-green-600 font-medium">
                                    Selected: {supervisorOrderData.products[product.id]} units
                                    {product.price && (
                                      <span className="text-gray-600 ml-2">
                                        (Total: ₹{(parseInt(supervisorOrderData.products[product.id]) * product.price).toLocaleString('en-IN')})
                                      </span>
                                    )}
                                  </div>
                                )}
                              </div>
                            ))}
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </div>
              )}

              {/* Error and Success Messages */}
              {error && (
                <div className="text-sm text-destructive bg-destructive/10 p-3 rounded-md">
                  {error}
                </div>
              )}

              {successMessage && (
                <div className="text-sm text-green-700 bg-green-50 p-3 rounded-md">
                  {successMessage}
                </div>
              )}

              {/* Dialog Footer */}
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setShowSupervisorOrderDialog(false)
                    setSupervisorOrderData({
                      shopId: '',
                      distributorId: '',
                      products: {},
                      shopStockAvailability: '',
                      distributorStockAvailability: '',
                    })
                  }}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="bg-[#433228] hover:bg-[#5a4238] text-white"
                  disabled={
                    loading || 
                    !supervisorOrderData.shopId || 
                    !supervisorOrderData.distributorId
                  }
                >
                  {loading ? 'Submitting...' : 'Create Order'}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      )}

      {/* RSM Order Creation Dialog */}
      {isRSM && (
        <Dialog open={showRSMOrderDialog} onOpenChange={setShowRSMOrderDialog}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create New Order</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleRSMOrderSubmit} className="space-y-6">
              {/* Entity Type Selection */}
              <div className="space-y-2">
                <Label>Select Entity Type *</Label>
                <Select
                  value={rsmOrderData.entityType}
                  onChange={(e) => {
                    setRsmOrderData({
                      ...rsmOrderData,
                      entityType: e.target.value,
                      entityId: '',
                    })
                  }}
                  required
                >
                  <option value="ss">Super Stockist (SS)</option>
                  <option value="distributor">Distributor</option>
                  <option value="shop">Shop</option>
                </Select>
              </div>

              {/* Entity Selection */}
              <div className="space-y-2">
                <Label>
                  Select {rsmOrderData.entityType === 'ss' ? 'SS' : rsmOrderData.entityType === 'distributor' ? 'Distributor' : 'Shop'} *
                </Label>
                <Select
                  value={rsmOrderData.entityId}
                  onChange={(e) => {
                    setRsmOrderData({
                      ...rsmOrderData,
                      entityId: e.target.value,
                    })
                  }}
                  required
                >
                  <option value="">Select {rsmOrderData.entityType === 'ss' ? 'SS' : rsmOrderData.entityType === 'distributor' ? 'Distributor' : 'Shop'}</option>
                  {rsmOrderData.entityType === 'ss' && ssList.map((ss) => (
                    <option key={ss.id} value={ss.id}>
                      {ss.name}
                    </option>
                  ))}
                  {rsmOrderData.entityType === 'distributor' && distributors.map((dist) => (
                    <option key={dist.id} value={dist.id}>
                      {dist.name}
                    </option>
                  ))}
                  {rsmOrderData.entityType === 'shop' && shops.map((shop) => (
                    <option key={shop.id} value={shop.id}>
                      {shop.name}
                    </option>
                  ))}
                </Select>
              </div>

              {/* All Categories Products - Single View */}
              {rsmOrderData.entityId && (
                <div className="space-y-4 border-t pt-4">
                  <Label className="text-lg font-semibold">Select Products - All Categories</Label>
                  <p className="text-sm text-gray-600 mb-4">Add quantities for products across all categories</p>
                  
                  <div className="space-y-6 max-h-[500px] overflow-y-auto pr-2">
                    {COSMETICS_CATEGORIES.map((category) => {
                      const categoryProducts = getProductsByCategory(category.name)
                      return (
                        <div key={category.id} className="border rounded-lg p-4 space-y-4 bg-white">
                          <Label className="text-lg font-semibold text-[#433228] border-b pb-2 block">
                            {category.name}
                          </Label>
                          <div className="space-y-3">
                            {categoryProducts.map((product) => (
                              <div key={product.id} className="space-y-2 bg-gray-50 p-3 rounded-lg border">
                                <div className="flex items-start gap-4">
                                  {/* Product Image */}
                                  <div className="flex-shrink-0">
                                    <img
                                      src={product.image || 'https://via.placeholder.com/100?text=Product'}
                                      alt={product.name}
                                      className="w-20 h-20 object-cover rounded-lg border border-gray-200"
                                      onError={(e) => {
                                        e.target.src = 'https://via.placeholder.com/100?text=Product'
                                      }}
                                    />
                                  </div>
                                  {/* Product Details */}
                                  <div className="flex-1">
                                    <Label className="text-base font-medium">{product.name}</Label>
                                    <p className="text-xs text-gray-500">Code: {product.code} | Price: ₹{product.price}/{product.unit}</p>
                                  </div>
                                </div>
                                
                                {/* Quantity Input with Increment/Decrement */}
                                <div className="flex items-center gap-3">
                                  <Label className="w-24 text-sm">Quantity:</Label>
                                  <div className="flex items-center gap-1">
                                    <Button
                                      type="button"
                                      variant="outline"
                                      size="sm"
                                      onClick={() => handleRSMQuantityChange(product.id, rsmOrderData.products[product.id] || '0', 'decrement')}
                                      className="h-9 w-9"
                                    >
                                      -
                                    </Button>
                                    <Input
                                      type="number"
                                      min="0"
                                      placeholder="0"
                                      value={rsmOrderData.products[product.id] || ''}
                                      onChange={(e) => {
                                        const value = e.target.value === '' ? '' : Math.max(0, parseInt(e.target.value) || 0)
                                        handleRSMProductQuantity(product.id, value.toString())
                                      }}
                                      onInput={(e) => {
                                        if (e.target.value < 0) e.target.value = 0
                                      }}
                                      className="w-24 text-center"
                                    />
                                    <Button
                                      type="button"
                                      variant="outline"
                                      size="sm"
                                      onClick={() => handleRSMQuantityChange(product.id, rsmOrderData.products[product.id] || '0', 'increment')}
                                      className="h-9 w-9"
                                    >
                                      +
                                    </Button>
                                  </div>
                                  <span className="text-sm text-gray-500">units</span>
                                  
                                  {/* Display Selected Quantity and Total */}
                                  {rsmOrderData.products[product.id] && parseInt(rsmOrderData.products[product.id]) > 0 && (
                                    <div className="ml-auto text-sm text-green-600 font-medium">
                                      Total: ₹{(parseInt(rsmOrderData.products[product.id]) * product.price).toLocaleString('en-IN')}
                                    </div>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )
                    })}
                  </div>

                  {/* Overall Order Summary */}
                  {Object.keys(rsmOrderData.products).some(productId => parseInt(rsmOrderData.products[productId]) > 0) && (
                    <div className="p-4 bg-green-50 rounded-lg border-2 border-green-200 mt-4">
                      <div className="flex justify-between items-center">
                        <span className="font-semibold text-green-800 text-lg">Overall Order Value:</span>
                        <span className="text-2xl font-bold text-green-700">
                          ₹{Object.entries(rsmOrderData.products).reduce((sum, [productId, quantity]) => {
                            const product = MOCK_PRODUCTS.find(p => p.id === parseInt(productId))
                            return sum + (parseInt(quantity) * (product?.price || 0))
                          }, 0).toLocaleString('en-IN')}
                        </span>
                      </div>
                      <div className="mt-2 text-sm text-gray-600">
                        Total Products: {Object.values(rsmOrderData.products).filter(qty => parseInt(qty) > 0).length} | 
                        Total Quantity: {Object.values(rsmOrderData.products).reduce((sum, qty) => sum + (parseInt(qty) || 0), 0)} units
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Error and Success Messages */}
              {error && (
                <div className="text-sm text-destructive bg-destructive/10 p-3 rounded-md">
                  {error}
                </div>
              )}

              {successMessage && (
                <div className="text-sm text-green-700 bg-green-50 p-3 rounded-md">
                  {successMessage}
                </div>
              )}

              {/* Dialog Footer */}
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setShowRSMOrderDialog(false)
                    setRsmOrderData({
                      entityType: 'ss',
                      entityId: '',
                      products: {},
                    })
                  }}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="bg-[#433228] hover:bg-[#5a4238] text-white"
                  disabled={
                    loading || 
                    !rsmOrderData.entityId ||
                    !Object.values(rsmOrderData.products).some(qty => parseInt(qty) > 0)
                  }
                >
                  {loading ? 'Submitting...' : 'Create Order'}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      )}

      {/* Order View Dialog for RSM and Supervisor */}
      {(isRSM || isSupervisor) && selectedOrder && (
        <Dialog open={showOrderViewDialog} onOpenChange={setShowOrderViewDialog}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Order Details</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              {/* Order Info */}
              <div className="grid grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg">
                <div>
                  <p className="text-sm text-gray-600">Order ID</p>
                  <p className="font-semibold">{selectedOrder.orderId || `ORD-${selectedOrder.id}`}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Batch ID</p>
                  <p className="font-semibold">{selectedOrder.batchId || `BATCH-${selectedOrder.id}`}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">{isSupervisor ? 'Shop' : 'Entity'}</p>
                  <p className="font-semibold">{getEntityName(selectedOrder)}</p>
                </div>
                {isSupervisor && selectedOrder.distributorName && (
                  <div>
                    <p className="text-sm text-gray-600">Distributor</p>
                    <p className="font-semibold">{selectedOrder.distributorName}</p>
                  </div>
                )}
                {!isSupervisor && (
                  <div>
                    <p className="text-sm text-gray-600">Status</p>
                    <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs">
                      {selectedOrder.status || 'Pending'}
                    </span>
                  </div>
                )}
                {isSupervisor && (
                  <div>
                    <p className="text-sm text-gray-600">Order Date</p>
                    <p className="font-semibold">
                      {selectedOrder.createdAt ? new Date(selectedOrder.createdAt).toLocaleDateString() : 'Just now'}
                    </p>
                  </div>
                )}
              </div>

              {/* Category Tabs with Products */}
              {selectedOrder.products && Object.keys(selectedOrder.products).length > 0 ? (
                <Tabs defaultValue={COSMETICS_CATEGORIES.find(cat => {
                  const categoryProducts = getProductsByCategory(cat.name)
                  return categoryProducts.some(product => 
                    selectedOrder.products[product.id] && parseInt(selectedOrder.products[product.id]) > 0
                  )
                })?.name || COSMETICS_CATEGORIES[0]?.name} className="w-full">
                  <TabsList className="grid w-full grid-cols-4">
                    {COSMETICS_CATEGORIES.map((category) => {
                      // Check if category has products
                      const categoryProducts = getProductsByCategory(category.name)
                      const hasProductsInOrder = categoryProducts.some(product => 
                        selectedOrder.products[product.id] && parseInt(selectedOrder.products[product.id]) > 0
                      )
                      return hasProductsInOrder ? (
                        <TabsTrigger key={category.id} value={category.name}>
                          {category.name}
                        </TabsTrigger>
                      ) : null
                    })}
                  </TabsList>

                  {COSMETICS_CATEGORIES.map((category) => {
                    const categoryProducts = getProductsByCategory(category.name)
                    const orderProductsInCategory = categoryProducts.filter(product => 
                      selectedOrder.products[product.id] && parseInt(selectedOrder.products[product.id]) > 0
                    )

                    if (orderProductsInCategory.length === 0) return null

                    return (
                      <TabsContent key={category.id} value={category.name} className="space-y-4">
                        <div className="border rounded-lg p-4">
                          <h3 className="text-lg font-semibold text-[#433228] mb-4">{category.name}</h3>
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead>Image</TableHead>
                                <TableHead>Product Name</TableHead>
                                <TableHead>Code</TableHead>
                                <TableHead className="text-right">Price</TableHead>
                                <TableHead className="text-right">Quantity</TableHead>
                                <TableHead className="text-right">Total Value</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {orderProductsInCategory.map((product) => {
                                const quantity = parseInt(selectedOrder.products[product.id]) || 0
                                const totalValue = quantity * product.price
                                return (
                                  <TableRow key={product.id}>
                                    <TableCell>
                                      <img
                                        src={product.image || 'https://via.placeholder.com/60?text=Product'}
                                        alt={product.name}
                                        className="w-12 h-12 object-cover rounded border border-gray-200"
                                        onError={(e) => {
                                          e.target.src = 'https://via.placeholder.com/60?text=Product'
                                        }}
                                      />
                                    </TableCell>
                                    <TableCell className="font-medium">{product.name}</TableCell>
                                    <TableCell>{product.code}</TableCell>
                                    <TableCell className="text-right">₹{product.price}/{product.unit}</TableCell>
                                    <TableCell className="text-right">{quantity} units</TableCell>
                                    <TableCell className="text-right font-semibold text-green-600">
                                      ₹{totalValue.toLocaleString('en-IN')}
                                    </TableCell>
                                  </TableRow>
                                )
                              })}
                            </TableBody>
                          </Table>
                        </div>
                      </TabsContent>
                    )
                  })}
                </Tabs>
              ) : (
                <p className="text-center text-gray-500 py-8">No products in this order</p>
              )}

              {/* Overall Value Summary */}
              {selectedOrder.products && Object.keys(selectedOrder.products).length > 0 && (
                <div className="p-4 bg-green-50 rounded-lg border-2 border-green-200">
                  <div className="flex justify-between items-center">
                    <span className="font-semibold text-green-800 text-lg">Overall Value:</span>
                    <span className="text-2xl font-bold text-green-700">
                      ₹{Object.entries(selectedOrder.products).reduce((sum, [productId, quantity]) => {
                        const product = MOCK_PRODUCTS.find(p => p.id === parseInt(productId))
                        return sum + (parseInt(quantity) * (product?.price || 0))
                      }, 0).toLocaleString('en-IN')}
                    </span>
                  </div>
                </div>
              )}
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}

export default Orders
