import { useState } from 'react'
import { useSelector } from 'react-redux'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Label } from '../../components/ui/label'
import { Select } from '../../components/ui/select'
import { Input } from '../../components/ui/input'
import { Textarea } from '../../components/ui/textarea'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '../../components/ui/dialog'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../../components/ui/table'
import { MOCK_SUPERVISOR_PROMOTERS } from '../../data/mockData'
import { User, Calendar } from 'lucide-react'

const Profile = () => {
  const { user } = useSelector((state) => state.auth)
  const [showLeaveDialog, setShowLeaveDialog] = useState(false)
  const [leaveData, setLeaveData] = useState({
    promoterId: '',
    startDate: '',
    endDate: '',
    reason: '',
    type: 'Casual Leave',
  })
  const [leaves, setLeaves] = useState([
    {
      id: 1,
      promoterId: 1,
      promoterName: 'Kavitha Rani',
      promoterCode: 'PROM001',
      startDate: '2024-01-15',
      endDate: '2024-01-17',
      days: 3,
      type: 'Casual Leave',
      reason: 'Personal work',
      status: 'Pending',
      appliedAt: '2024-01-10',
    },
    {
      id: 2,
      promoterId: 2,
      promoterName: 'Selvi Murugan',
      promoterCode: 'PROM002',
      startDate: '2024-01-20',
      endDate: '2024-01-20',
      days: 1,
      type: 'Sick Leave',
      reason: 'Medical appointment',
      status: 'Approved',
      appliedAt: '2024-01-18',
    },
  ])

  const handleAddLeave = () => {
    if (!leaveData.promoterId || !leaveData.startDate || !leaveData.endDate || !leaveData.reason) {
      alert('Please fill all required fields')
      return
    }

    const start = new Date(leaveData.startDate)
    const end = new Date(leaveData.endDate)
    
    if (end < start) {
      alert('End date must be after start date')
      return
    }

    const days = Math.ceil((end - start) / (1000 * 60 * 60 * 24)) + 1
    const promoter = MOCK_SUPERVISOR_PROMOTERS.find(p => p.id === parseInt(leaveData.promoterId))

    const newLeave = {
      id: Date.now(),
      promoterId: parseInt(leaveData.promoterId),
      promoterName: promoter?.name || 'Unknown',
      promoterCode: promoter?.code || '',
      startDate: leaveData.startDate,
      endDate: leaveData.endDate,
      days,
      type: leaveData.type,
      reason: leaveData.reason,
      status: 'Pending',
      appliedAt: new Date().toISOString().split('T')[0],
    }

    setLeaves(prev => [newLeave, ...prev])
    setShowLeaveDialog(false)
    setLeaveData({
      promoterId: '',
      startDate: '',
      endDate: '',
      reason: '',
      type: 'Casual Leave',
    })
    alert('Leave request added successfully!')
  }

  const handleApproveLeave = (leaveId) => {
    setLeaves(prev => prev.map(leave => 
      leave.id === leaveId ? { ...leave, status: 'Approved' } : leave
    ))
  }

  const handleRejectLeave = (leaveId) => {
    setLeaves(prev => prev.map(leave => 
      leave.id === leaveId ? { ...leave, status: 'Rejected' } : leave
    ))
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">My Profile</h1>
        <p className="text-gray-600 mt-2">Supervisor details and promoter leave management</p>
      </div>

      {/* Supervisor Profile */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Supervisor Details
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-600">Name</p>
              <p className="font-semibold">{user?.name || 'Supervisor User'}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Role</p>
              <p className="font-semibold">{user?.role || 'Supervisor'}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Email</p>
              <p className="font-semibold">{user?.email || 'supervisor@example.com'}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Supervisor ID</p>
              <p className="font-semibold">{user?.supervisorId || 'SUP001'}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Promoter Leave Management */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Promoter Leave Management
          </CardTitle>
          <CardDescription>Manage leave requests from promoters</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Button
            onClick={() => setShowLeaveDialog(true)}
            className="bg-[#433228] hover:bg-[#5a4238]"
          >
            Add Leave Request
          </Button>

          {leaves.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Promoter</TableHead>
                  <TableHead>Code</TableHead>
                  <TableHead>Leave Type</TableHead>
                  <TableHead>Start Date</TableHead>
                  <TableHead>End Date</TableHead>
                  <TableHead>Days</TableHead>
                  <TableHead>Reason</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Applied At</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {leaves.map((leave) => (
                  <TableRow key={leave.id}>
                    <TableCell className="font-medium">{leave.promoterName}</TableCell>
                    <TableCell>{leave.promoterCode}</TableCell>
                    <TableCell>{leave.type}</TableCell>
                    <TableCell>{new Date(leave.startDate).toLocaleDateString()}</TableCell>
                    <TableCell>{new Date(leave.endDate).toLocaleDateString()}</TableCell>
                    <TableCell>{leave.days} day(s)</TableCell>
                    <TableCell className="max-w-xs truncate">{leave.reason}</TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        leave.status === 'Approved' ? 'bg-green-100 text-green-800' :
                        leave.status === 'Rejected' ? 'bg-red-100 text-red-800' :
                        'bg-yellow-100 text-yellow-800'
                      }`}>
                        {leave.status}
                      </span>
                    </TableCell>
                    <TableCell>{new Date(leave.appliedAt).toLocaleDateString()}</TableCell>
                    <TableCell>
                      {leave.status === 'Pending' && (
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-green-600 border-green-600 hover:bg-green-50"
                            onClick={() => handleApproveLeave(leave.id)}
                          >
                            Approve
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-red-600 border-red-600 hover:bg-red-50"
                            onClick={() => handleRejectLeave(leave.id)}
                          >
                            Reject
                          </Button>
                        </div>
                      )}
                      {leave.status !== 'Pending' && (
                        <span className="text-xs text-gray-500">No action</span>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <Card className="bg-gray-50">
              <CardContent className="pt-6">
                <p className="text-center text-gray-500">No leave requests yet</p>
              </CardContent>
            </Card>
          )}
        </CardContent>
      </Card>

      {/* Add Leave Dialog */}
      <Dialog open={showLeaveDialog} onOpenChange={setShowLeaveDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Promoter Leave Request</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Select Promoter *</Label>
              <Select
                value={leaveData.promoterId}
                onChange={(e) => setLeaveData({ ...leaveData, promoterId: e.target.value })}
              >
                <option value="">Select Promoter</option>
                {MOCK_SUPERVISOR_PROMOTERS.map((promoter) => (
                  <option key={promoter.id} value={promoter.id}>
                    {promoter.name} ({promoter.code})
                  </option>
                ))}
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Leave Type *</Label>
              <Select
                value={leaveData.type}
                onChange={(e) => setLeaveData({ ...leaveData, type: e.target.value })}
              >
                <option value="Casual Leave">Casual Leave</option>
                <option value="Sick Leave">Sick Leave</option>
                <option value="Emergency Leave">Emergency Leave</option>
                <option value="Other">Other</option>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Start Date *</Label>
                <Input
                  type="date"
                  value={leaveData.startDate}
                  onChange={(e) => setLeaveData({ ...leaveData, startDate: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label>End Date *</Label>
                <Input
                  type="date"
                  value={leaveData.endDate}
                  onChange={(e) => setLeaveData({ ...leaveData, endDate: e.target.value })}
                  min={leaveData.startDate}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Reason *</Label>
              <Textarea
                placeholder="Enter reason for leave..."
                value={leaveData.reason}
                onChange={(e) => setLeaveData({ ...leaveData, reason: e.target.value })}
                rows={4}
                required
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowLeaveDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddLeave} className="bg-[#433228] hover:bg-[#5a4238]">
              Add Leave Request
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

export default Profile
