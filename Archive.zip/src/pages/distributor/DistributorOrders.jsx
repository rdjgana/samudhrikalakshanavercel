import { useState } from 'react'
import { useSelector } from 'react-redux'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Input } from '../../components/ui/input'
import { Label } from '../../components/ui/label'
import { Select } from '../../components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../../components/ui/table'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../components/ui/tabs'
import { Check, X, Edit, Eye } from 'lucide-react'
import { MOCK_PRODUCTS, COSMETICS_CATEGORIES, MOCK_SS_LIST, MOCK_SHOPS } from '../../data/mockData'

// Mock SS Stock for ordering
const getSSStock = () => {
  return MOCK_PRODUCTS.map((product) => ({
    id: product.id,
    name: product.name,
    category: product.category,
    price: product.price * 0.9, // Distributor price (10% discount from SS)
    availableCases: Math.floor(Math.random() * 80) + 40,
    piecesPerCase: product.category === 'Personal Care' && product.name === 'Soap' ? 60 : 
                   product.category === 'Hair Care' ? 24 : 12,
  }))
}

const MOCK_SS_STOCK = getSSStock()

// Mock Shop Orders
const MOCK_SHOP_ORDERS = [
  {
    id: 1,
    shopId: 1,
    shopName: 'Beauty Zone T Nagar',
    area: 'T Nagar',
    items: [
      { productId: 1, productName: 'Face Wash', quantity: 3, value: 6750 },
      { productId: 5, productName: 'Body Lotion', quantity: 2, value: 5400 },
    ],
    totalValue: 12150,
    status: 'pending',
    createdAt: '2026-01-28T10:00:00Z',
  },
  {
    id: 2,
    shopId: 2,
    shopName: 'Glow Beauty Parlour',
    area: 'Anna Nagar',
    items: [
      { productId: 13, productName: 'Soap', quantity: 5, value: 13500 },
    ],
    totalValue: 13500,
    status: 'pending',
    createdAt: '2026-01-27T14:30:00Z',
  },
]

const DistributorOrders = () => {
  const { user } = useSelector((state) => state.auth)
  const [activeTab, setActiveTab] = useState('create')
  const [orderType, setOrderType] = useState('ss') // 'ss' or 'shop'
  const [createOrderData, setCreateOrderData] = useState({
    entityId: '', // SS ID or Shop ID
    category: '',
    products: {}, // { productId: { quantity: cases, price } }
  })
  const [selectedShop, setSelectedShop] = useState('')
  const [selectedArea, setSelectedArea] = useState('')

  // Get shops assigned to this distributor
  const assignedShops = MOCK_SHOPS.filter(shop => shop.distributorId === user?.distributorId || shop.distributorId === 1)

  const handleCreateOrder = () => {
    if (!createOrderData.entityId || !createOrderData.category) {
      alert('Please select entity and category')
      return
    }
    const selectedProducts = Object.keys(createOrderData.products).filter(
      pid => createOrderData.products[pid]?.quantity > 0
    )
    if (selectedProducts.length === 0) {
      alert('Please select at least one product')
      return
    }
    alert('Order created successfully!')
    setCreateOrderData({ entityId: '', category: '', products: {} })
  }

  const handleAcceptOrder = (orderId) => {
    if (confirm('Are you sure you want to accept this order? This will deduct stock from Distributor Stock.')) {
      alert('Order accepted successfully! Stock deducted.')
    }
  }

  const handleModifyOrder = (order) => {
    alert('Modify order functionality - Open edit dialog')
  }

  const handleRejectOrder = (orderId) => {
    if (confirm('Are you sure you want to reject this order?')) {
      alert('Order rejected successfully!')
    }
  }

  const filteredShopOrders = selectedShop && selectedArea
    ? MOCK_SHOP_ORDERS.filter(
        order => order.shopId === parseInt(selectedShop) && order.area === selectedArea
      )
    : selectedShop
    ? MOCK_SHOP_ORDERS.filter(order => order.shopId === parseInt(selectedShop))
    : []

  const categoryProducts = createOrderData.category
    ? (orderType === 'ss' 
        ? MOCK_SS_STOCK.filter(p => p.category === createOrderData.category)
        : MOCK_PRODUCTS.filter(p => p.category === createOrderData.category).map(p => ({
            ...p,
            price: p.price * 1.1, // Shop price (10% markup)
            availableCases: Math.floor(Math.random() * 50) + 20,
            piecesPerCase: p.category === 'Personal Care' && p.name === 'Soap' ? 60 : 
                          p.category === 'Hair Care' ? 24 : 12,
          }))
      )
    : []

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Order Management</h1>
        <p className="text-gray-600 mt-2">Create orders and manage shop orders</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="create">Create Order</TabsTrigger>
          <TabsTrigger value="view">View Order (Shop Fulfillment)</TabsTrigger>
        </TabsList>

        {/* Create Order Tab */}
        <TabsContent value="create">
          <Card>
            <CardHeader>
              <CardTitle>Create Order</CardTitle>
              <CardDescription>Create orders for SS or Shop</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Order Type *</Label>
                  <div className="flex gap-4">
                    <label className="flex items-center space-x-2">
                      <input
                        type="radio"
                        name="orderType"
                        value="ss"
                        checked={orderType === 'ss'}
                        onChange={(e) => {
                          setOrderType(e.target.value)
                          setCreateOrderData({ entityId: '', category: '', products: {} })
                        }}
                      />
                      <span>SS (Super Stockist)</span>
                    </label>
                    <label className="flex items-center space-x-2">
                      <input
                        type="radio"
                        name="orderType"
                        value="shop"
                        checked={orderType === 'shop'}
                        onChange={(e) => {
                          setOrderType(e.target.value)
                          setCreateOrderData({ entityId: '', category: '', products: {} })
                        }}
                      />
                      <span>Shop</span>
                    </label>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="entity">
                    {orderType === 'ss' ? 'Select SS Name *' : 'Select Shop Name *'}
                  </Label>
                  <Select
                    id="entity"
                    value={createOrderData.entityId}
                    onChange={(e) => setCreateOrderData({ ...createOrderData, entityId: e.target.value, category: '', products: {} })}
                  >
                    <option value="">Select {orderType === 'ss' ? 'SS' : 'Shop'}</option>
                    {orderType === 'ss' 
                      ? MOCK_SS_LIST.map((ss) => (
                          <option key={ss.id} value={ss.id}>
                            {ss.name} - {ss.city}
                          </option>
                        ))
                      : assignedShops.map((shop) => (
                          <option key={shop.id} value={shop.id}>
                            {shop.name} - {shop.address}
                          </option>
                        ))
                    }
                  </Select>
                </div>

                {createOrderData.entityId && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="category">Product Category *</Label>
                      <Select
                        id="category"
                        value={createOrderData.category}
                        onChange={(e) => setCreateOrderData({ ...createOrderData, category: e.target.value, products: {} })}
                      >
                        <option value="">Select Category</option>
                        {COSMETICS_CATEGORIES.map((category) => (
                          <option key={category.id} value={category.name}>
                            {category.name}
                          </option>
                        ))}
                      </Select>
                    </div>

                    {createOrderData.category && categoryProducts.length > 0 && (
                      <div className="space-y-4">
                        <h3 className="font-semibold">Available Products</h3>
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Product Name</TableHead>
                              <TableHead>Price</TableHead>
                              <TableHead>Available Cases</TableHead>
                              <TableHead>Pieces per Case</TableHead>
                              <TableHead>Order Quantity (Cases)</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {categoryProducts.map((product) => (
                              <TableRow key={product.id}>
                                <TableCell className="font-medium">{product.name}</TableCell>
                                <TableCell>₹{product.price}</TableCell>
                                <TableCell>{product.availableCases}</TableCell>
                                <TableCell>{product.piecesPerCase} pieces</TableCell>
                                <TableCell>
                                  <Input
                                    type="number"
                                    min="0"
                                    max={product.availableCases}
                                    value={createOrderData.products[product.id]?.quantity || ''}
                                    onChange={(e) => {
                                      const quantity = parseInt(e.target.value) || 0
                                      setCreateOrderData({
                                        ...createOrderData,
                                        products: {
                                          ...createOrderData.products,
                                          [product.id]: {
                                            quantity,
                                            price: product.price,
                                            name: product.name,
                                          },
                                        },
                                      })
                                    }}
                                    className="w-24"
                                  />
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>

                        {Object.keys(createOrderData.products).some(pid => createOrderData.products[pid]?.quantity > 0) && (
                          <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                            <h4 className="font-semibold mb-2">Order Summary</h4>
                            {Object.entries(createOrderData.products).map(([productId, data]) => {
                              if (!data.quantity) return null
                              const product = categoryProducts.find(p => p.id === parseInt(productId))
                              return (
                                <div key={productId} className="flex justify-between text-sm">
                                  <span>{data.name} - {data.quantity} case(s)</span>
                                  <span>₹{(data.quantity * data.price * product.piecesPerCase).toLocaleString('en-IN')}</span>
                                </div>
                              )
                            })}
                            <div className="mt-2 pt-2 border-t flex justify-between font-semibold">
                              <span>Total Value:</span>
                              <span>
                                ₹{Object.entries(createOrderData.products).reduce((sum, [productId, data]) => {
                                  if (!data.quantity) return sum
                                  const product = categoryProducts.find(p => p.id === parseInt(productId))
                                  return sum + (data.quantity * data.price * product.piecesPerCase)
                                }, 0).toLocaleString('en-IN')}
                              </span>
                            </div>
                          </div>
                        )}

                        <Button
                          onClick={handleCreateOrder}
                          className="bg-[#433228] hover:bg-[#5a4238] text-white"
                        >
                          Complete Order
                        </Button>
                      </div>
                    )}
                  </>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* View Order Tab */}
        <TabsContent value="view">
          <Card>
            <CardHeader>
              <CardTitle>View Orders - Shop Fulfillment</CardTitle>
              <CardDescription>View and manage orders received from shops</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="shop">Shop Name *</Label>
                    <Select
                      id="shop"
                      value={selectedShop}
                      onChange={(e) => {
                        setSelectedShop(e.target.value)
                        const shop = assignedShops.find(s => s.id === parseInt(e.target.value))
                        setSelectedArea(shop?.address.split(',')[1]?.trim() || '')
                      }}
                    >
                      <option value="">Select Shop</option>
                      {assignedShops.map((shop) => (
                        <option key={shop.id} value={shop.id}>
                          {shop.name}
                        </option>
                      ))}
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="area">Area *</Label>
                    <Input
                      id="area"
                      value={selectedArea}
                      onChange={(e) => setSelectedArea(e.target.value)}
                      placeholder="Enter area"
                    />
                  </div>
                </div>

                {filteredShopOrders.length > 0 && (
                  <div className="mt-6">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>S.No</TableHead>
                          <TableHead>Item View</TableHead>
                          <TableHead>Qnty</TableHead>
                          <TableHead>Value</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredShopOrders.map((order, index) => (
                          <TableRow key={order.id}>
                            <TableCell>{index + 1}</TableCell>
                            <TableCell>
                              {order.items.map(item => item.productName).join(', ')}
                            </TableCell>
                            <TableCell>
                              {order.items.reduce((sum, item) => sum + item.quantity, 0)} cases
                            </TableCell>
                            <TableCell>₹{order.totalValue.toLocaleString('en-IN')}</TableCell>
                            <TableCell>
                              <div className="flex gap-2">
                                <Button
                                  size="sm"
                                  onClick={() => handleAcceptOrder(order.id)}
                                  className="bg-green-600 hover:bg-green-700 text-white"
                                >
                                  <Check className="h-4 w-4" />
                                </Button>
                                <Button
                                  size="sm"
                                  onClick={() => handleModifyOrder(order)}
                                  className="bg-blue-600 hover:bg-blue-700 text-white"
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button
                                  size="sm"
                                  onClick={() => handleRejectOrder(order.id)}
                                  className="bg-red-600 hover:bg-red-700 text-white"
                                >
                                  <X className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}

                {selectedShop && filteredShopOrders.length === 0 && (
                  <p className="text-center text-gray-500 py-8">No pending orders found</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

export default DistributorOrders
