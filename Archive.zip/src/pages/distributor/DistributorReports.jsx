import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Label } from '../../components/ui/label'
import { Select } from '../../components/ui/select'
import { Input } from '../../components/ui/input'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../../components/ui/table'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../components/ui/tabs'
import { FileText, Download } from 'lucide-react'
import { MOCK_SHOPS, MOCK_SS_LIST } from '../../data/mockData'

// Mock Sales Report Data
const MOCK_SALES_REPORT = {
  primary: [
    { item: 'Face Wash', quantity: 25, value: 56250 },
    { item: 'Body Lotion', quantity: 20, value: 54000 },
    { item: 'Soap', quantity: 30, value: 81000 },
  ],
  secondary: [
    { item: 'Face Cream', quantity: 15, value: 60750 },
    { item: 'Hair Oil', quantity: 18, value: 24300 },
  ],
}

// Mock Purchase Report Data
const MOCK_PURCHASE_REPORT = [
  { date: '2026-01-15', ssName: 'Beauty Cosmetics Super Stockist', items: 'Face Wash, Body Lotion', quantity: 45, value: 101250 },
  { date: '2026-01-20', ssName: 'Beauty Cosmetics Super Stockist', items: 'Soap, Hand Wash', quantity: 60, value: 108000 },
  { date: '2026-01-25', ssName: 'Glow Beauty Wholesale', items: 'Face Cream, Hair Oil', quantity: 35, value: 94500 },
]

const DistributorReports = () => {
  const [activeTab, setActiveTab] = useState('sales')
  const [salesReportData, setSalesReportData] = useState({
    saleType: 'both', // 'primary', 'secondary', 'both'
    startDate: '',
    endDate: '',
  })
  const [purchaseReportData, setPurchaseReportData] = useState({
    startDate: '',
    endDate: '',
  })

  const handleGenerateSalesReport = () => {
    if (!salesReportData.startDate || !salesReportData.endDate) {
      alert('Please select date range')
      return
    }
    alert('Sales report generated successfully!')
  }

  const handleGeneratePurchaseReport = () => {
    if (!purchaseReportData.startDate || !purchaseReportData.endDate) {
      alert('Please select date range')
      return
    }
    alert('Purchase report generated successfully!')
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Sales & Purchase Reports</h1>
        <p className="text-gray-600 mt-2">Generate sales and purchase reports</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="sales">My Sales Report</TabsTrigger>
          <TabsTrigger value="purchase">Purchase Report</TabsTrigger>
        </TabsList>

        {/* My Sales Report */}
        <TabsContent value="sales">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-[#433228]" />
                My Sales Report
              </CardTitle>
              <CardDescription>Sales made to Shops</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="sale-type">Sale Type *</Label>
                    <Select
                      id="sale-type"
                      value={salesReportData.saleType}
                      onChange={(e) => setSalesReportData({ ...salesReportData, saleType: e.target.value })}
                    >
                      <option value="both">Both (Primary & Secondary)</option>
                      <option value="primary">Primary</option>
                      <option value="secondary">Secondary</option>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="start-date-sales">Start Date *</Label>
                    <Input
                      id="start-date-sales"
                      type="date"
                      value={salesReportData.startDate}
                      onChange={(e) => setSalesReportData({ ...salesReportData, startDate: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="end-date-sales">End Date *</Label>
                    <Input
                      id="end-date-sales"
                      type="date"
                      value={salesReportData.endDate}
                      onChange={(e) => setSalesReportData({ ...salesReportData, endDate: e.target.value })}
                    />
                  </div>
                </div>

                <Button
                  onClick={handleGenerateSalesReport}
                  className="bg-[#433228] hover:bg-[#5a4238] text-white"
                >
                  Generate Report
                </Button>

                {(salesReportData.startDate && salesReportData.endDate) && (
                  <div className="mt-6">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="font-semibold text-lg">Report Results</h3>
                      <Button variant="outline" size="sm">
                        <Download className="h-4 w-4 mr-2" />
                        Export
                      </Button>
                    </div>

                    {(salesReportData.saleType === 'primary' || salesReportData.saleType === 'both') && (
                      <div className="mb-6">
                        <h4 className="font-semibold mb-2">Primary Sales</h4>
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Item</TableHead>
                              <TableHead>Quantity</TableHead>
                              <TableHead>Value</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {MOCK_SALES_REPORT.primary.map((item, index) => (
                              <TableRow key={index}>
                                <TableCell className="font-medium">{item.item}</TableCell>
                                <TableCell>{item.quantity}</TableCell>
                                <TableCell>₹{item.value.toLocaleString('en-IN')}</TableCell>
                              </TableRow>
                            ))}
                            <TableRow className="font-semibold">
                              <TableCell>Total</TableCell>
                              <TableCell>
                                {MOCK_SALES_REPORT.primary.reduce((sum, item) => sum + item.quantity, 0)}
                              </TableCell>
                              <TableCell>
                                ₹{MOCK_SALES_REPORT.primary.reduce((sum, item) => sum + item.value, 0).toLocaleString('en-IN')}
                              </TableCell>
                            </TableRow>
                          </TableBody>
                        </Table>
                      </div>
                    )}

                    {(salesReportData.saleType === 'secondary' || salesReportData.saleType === 'both') && (
                      <div>
                        <h4 className="font-semibold mb-2">Secondary Sales</h4>
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Item</TableHead>
                              <TableHead>Quantity</TableHead>
                              <TableHead>Value</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {MOCK_SALES_REPORT.secondary.map((item, index) => (
                              <TableRow key={index}>
                                <TableCell className="font-medium">{item.item}</TableCell>
                                <TableCell>{item.quantity}</TableCell>
                                <TableCell>₹{item.value.toLocaleString('en-IN')}</TableCell>
                              </TableRow>
                            ))}
                            <TableRow className="font-semibold">
                              <TableCell>Total</TableCell>
                              <TableCell>
                                {MOCK_SALES_REPORT.secondary.reduce((sum, item) => sum + item.quantity, 0)}
                              </TableCell>
                              <TableCell>
                                ₹{MOCK_SALES_REPORT.secondary.reduce((sum, item) => sum + item.value, 0).toLocaleString('en-IN')}
                              </TableCell>
                            </TableRow>
                          </TableBody>
                        </Table>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Purchase Report */}
        <TabsContent value="purchase">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-[#433228]" />
                Purchase Report
              </CardTitle>
              <CardDescription>Purchase from SS (Super Stockist)</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="start-date-purchase">Start Date *</Label>
                    <Input
                      id="start-date-purchase"
                      type="date"
                      value={purchaseReportData.startDate}
                      onChange={(e) => setPurchaseReportData({ ...purchaseReportData, startDate: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="end-date-purchase">End Date *</Label>
                    <Input
                      id="end-date-purchase"
                      type="date"
                      value={purchaseReportData.endDate}
                      onChange={(e) => setPurchaseReportData({ ...purchaseReportData, endDate: e.target.value })}
                    />
                  </div>
                </div>

                <Button
                  onClick={handleGeneratePurchaseReport}
                  className="bg-[#433228] hover:bg-[#5a4238] text-white"
                >
                  Generate Report
                </Button>

                {(purchaseReportData.startDate && purchaseReportData.endDate) && (
                  <div className="mt-6">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="font-semibold text-lg">Purchase Report Results</h3>
                      <Button variant="outline" size="sm">
                        <Download className="h-4 w-4 mr-2" />
                        Export
                      </Button>
                    </div>

                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Date</TableHead>
                          <TableHead>SS Name</TableHead>
                          <TableHead>Items</TableHead>
                          <TableHead>Quantity</TableHead>
                          <TableHead>Value</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {MOCK_PURCHASE_REPORT.map((item, index) => (
                          <TableRow key={index}>
                            <TableCell>{new Date(item.date).toLocaleDateString()}</TableCell>
                            <TableCell className="font-medium">{item.ssName}</TableCell>
                            <TableCell>{item.items}</TableCell>
                            <TableCell>{item.quantity} cases</TableCell>
                            <TableCell>₹{item.value.toLocaleString('en-IN')}</TableCell>
                          </TableRow>
                        ))}
                        <TableRow className="font-semibold">
                          <TableCell colSpan={3}>Total</TableCell>
                          <TableCell>
                            {MOCK_PURCHASE_REPORT.reduce((sum, item) => sum + item.quantity, 0)} cases
                          </TableCell>
                          <TableCell>
                            ₹{MOCK_PURCHASE_REPORT.reduce((sum, item) => sum + item.value, 0).toLocaleString('en-IN')}
                          </TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

export default DistributorReports
