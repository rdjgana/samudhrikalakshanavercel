import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Label } from '../../components/ui/label'
import { Select } from '../../components/ui/select'
import { Input } from '../../components/ui/input'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../../components/ui/table'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../components/ui/tabs'
import { FileText, Download } from 'lucide-react'

// Mock data
const MOCK_DISTRIBUTORS = [
  { id: 1, name: 'Shraam', area: 'Sivakasi' },
  { id: 2, name: 'Raj Distributors', area: 'Madurai' },
  { id: 3, name: 'Kumar Agencies', area: 'Coimbatore' },
]

const MOCK_SHOPS = {
  1: [
    { id: 1, name: 'Beauty Zone Sivakasi' },
    { id: 2, name: 'Cosmetics Hub Sivakasi' },
  ],
  2: [
    { id: 3, name: 'Beauty Zone Madurai' },
    { id: 4, name: 'Cosmetics Hub Madurai' },
  ],
  3: [
    { id: 5, name: 'Beauty Zone Coimbatore' },
    { id: 6, name: 'Cosmetics Hub Coimbatore' },
  ],
}

const MOCK_DISTRIBUTOR_REPORT = {
  1: {
    primary: [
      { item: 'Gold Soap', quantity: 50, value: 150000 },
      { item: 'Silver Soap', quantity: 40, value: 108000 },
    ],
    secondary: [
      { item: 'Herbal Face Wash', quantity: 20, value: 120000 },
    ],
  },
  2: {
    primary: [
      { item: 'Gold Soap', quantity: 60, value: 180000 },
    ],
    secondary: [
      { item: 'Herbal Cream', quantity: 15, value: 202500 },
    ],
  },
}

const MOCK_SHOP_REPORT = {
  1: {
    primary: [
      { item: 'Gold Soap', quantity: 15, mrp: 50, value: 750 },
    ],
    secondary: [
      { item: 'Silver Soap', quantity: 12, mrp: 45, value: 540 },
    ],
  },
  3: {
    primary: [
      { item: 'Gold Soap', quantity: 20, mrp: 50, value: 1000 },
    ],
    secondary: [
      { item: 'Herbal Face Wash', quantity: 10, mrp: 250, value: 2500 },
    ],
  },
}

const SuperStockistReports = () => {
  const [activeTab, setActiveTab] = useState('distributor')
  const [distributorReportData, setDistributorReportData] = useState({
    distributorId: '',
    saleType: 'both', // 'primary', 'secondary', 'both'
    startDate: '',
    endDate: '',
  })
  const [shopReportData, setShopReportData] = useState({
    distributorId: '',
    shopId: '',
    saleType: 'both',
    startDate: '',
    endDate: '',
  })

  const handleGenerateDistributorReport = () => {
    if (!distributorReportData.distributorId || !distributorReportData.startDate || !distributorReportData.endDate) {
      alert('Please fill all required fields')
      return
    }
    // Generate report logic
    alert('Report generated successfully!')
  }

  const handleGenerateShopReport = () => {
    if (!shopReportData.distributorId || !shopReportData.shopId || !shopReportData.startDate || !shopReportData.endDate) {
      alert('Please fill all required fields')
      return
    }
    // Generate report logic
    alert('Report generated successfully!')
  }

  const selectedDistributorReport = distributorReportData.distributorId
    ? MOCK_DISTRIBUTOR_REPORT[parseInt(distributorReportData.distributorId)]
    : null

  const selectedShopReport = shopReportData.shopId
    ? MOCK_SHOP_REPORT[parseInt(shopReportData.shopId)]
    : null

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Sales & Purchase Reports</h1>
        <p className="text-gray-600 mt-2">Generate distributor-wise and shop-wise reports</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="distributor">Distributor-wise Report</TabsTrigger>
          <TabsTrigger value="shop">Shop-wise Report</TabsTrigger>
        </TabsList>

        {/* Distributor-wise Report */}
        <TabsContent value="distributor">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-[#433228]" />
                Distributor-wise Report
              </CardTitle>
              <CardDescription>Generate report based on Distributor Billing Data</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="distributor-report">Select Distributor *</Label>
                    <Select
                      id="distributor-report"
                      value={distributorReportData.distributorId}
                      onChange={(e) => setDistributorReportData({ ...distributorReportData, distributorId: e.target.value })}
                    >
                      <option value="">Select Distributor</option>
                      {MOCK_DISTRIBUTORS.map((dist) => (
                        <option key={dist.id} value={dist.id}>
                          {dist.name} - {dist.area}
                        </option>
                      ))}
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="sale-type-dist">Sale Type *</Label>
                    <Select
                      id="sale-type-dist"
                      value={distributorReportData.saleType}
                      onChange={(e) => setDistributorReportData({ ...distributorReportData, saleType: e.target.value })}
                    >
                      <option value="both">Both (Primary & Secondary)</option>
                      <option value="primary">Primary</option>
                      <option value="secondary">Secondary</option>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="start-date-dist">Start Date *</Label>
                    <Input
                      id="start-date-dist"
                      type="date"
                      value={distributorReportData.startDate}
                      onChange={(e) => setDistributorReportData({ ...distributorReportData, startDate: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="end-date-dist">End Date *</Label>
                    <Input
                      id="end-date-dist"
                      type="date"
                      value={distributorReportData.endDate}
                      onChange={(e) => setDistributorReportData({ ...distributorReportData, endDate: e.target.value })}
                    />
                  </div>
                </div>

                <Button
                  onClick={handleGenerateDistributorReport}
                  className="bg-[#433228] hover:bg-[#5a4238] text-white"
                >
                  Generate Report
                </Button>

                {selectedDistributorReport && (
                  <div className="mt-6">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="font-semibold text-lg">Report Results</h3>
                      <Button variant="outline" size="sm">
                        <Download className="h-4 w-4 mr-2" />
                        Export
                      </Button>
                    </div>

                    {(distributorReportData.saleType === 'primary' || distributorReportData.saleType === 'both') && (
                      <div className="mb-6">
                        <h4 className="font-semibold mb-2">Primary Sales</h4>
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Item</TableHead>
                              <TableHead>Quantity</TableHead>
                              <TableHead>Value</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {selectedDistributorReport.primary.map((item, index) => (
                              <TableRow key={index}>
                                <TableCell className="font-medium">{item.item}</TableCell>
                                <TableCell>{item.quantity}</TableCell>
                                <TableCell>₹{item.value.toLocaleString('en-IN')}</TableCell>
                              </TableRow>
                            ))}
                            <TableRow className="font-semibold">
                              <TableCell>Total</TableCell>
                              <TableCell>
                                {selectedDistributorReport.primary.reduce((sum, item) => sum + item.quantity, 0)}
                              </TableCell>
                              <TableCell>
                                ₹{selectedDistributorReport.primary.reduce((sum, item) => sum + item.value, 0).toLocaleString('en-IN')}
                              </TableCell>
                            </TableRow>
                          </TableBody>
                        </Table>
                      </div>
                    )}

                    {(distributorReportData.saleType === 'secondary' || distributorReportData.saleType === 'both') && (
                      <div>
                        <h4 className="font-semibold mb-2">Secondary Sales</h4>
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Item</TableHead>
                              <TableHead>Quantity</TableHead>
                              <TableHead>Value</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {selectedDistributorReport.secondary.map((item, index) => (
                              <TableRow key={index}>
                                <TableCell className="font-medium">{item.item}</TableCell>
                                <TableCell>{item.quantity}</TableCell>
                                <TableCell>₹{item.value.toLocaleString('en-IN')}</TableCell>
                              </TableRow>
                            ))}
                            <TableRow className="font-semibold">
                              <TableCell>Total</TableCell>
                              <TableCell>
                                {selectedDistributorReport.secondary.reduce((sum, item) => sum + item.quantity, 0)}
                              </TableCell>
                              <TableCell>
                                ₹{selectedDistributorReport.secondary.reduce((sum, item) => sum + item.value, 0).toLocaleString('en-IN')}
                              </TableCell>
                            </TableRow>
                          </TableBody>
                        </Table>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Shop-wise Report */}
        <TabsContent value="shop">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-[#433228]" />
                Shop-wise Report
              </CardTitle>
              <CardDescription>Generate report based on MRP (Shop Value)</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="distributor-shop-report">Select Distributor *</Label>
                    <Select
                      id="distributor-shop-report"
                      value={shopReportData.distributorId}
                      onChange={(e) => {
                        setShopReportData({ ...shopReportData, distributorId: e.target.value, shopId: '' })
                      }}
                    >
                      <option value="">Select Distributor</option>
                      {MOCK_DISTRIBUTORS.map((dist) => (
                        <option key={dist.id} value={dist.id}>
                          {dist.name} - {dist.area}
                        </option>
                      ))}
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="shop-report">Select Shop *</Label>
                    <Select
                      id="shop-report"
                      value={shopReportData.shopId}
                      onChange={(e) => setShopReportData({ ...shopReportData, shopId: e.target.value })}
                      disabled={!shopReportData.distributorId}
                    >
                      <option value="">Select Shop</option>
                      {shopReportData.distributorId && MOCK_SHOPS[parseInt(shopReportData.distributorId)]?.map((shop) => (
                        <option key={shop.id} value={shop.id}>
                          {shop.name}
                        </option>
                      ))}
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="sale-type-shop">Sale Type *</Label>
                    <Select
                      id="sale-type-shop"
                      value={shopReportData.saleType}
                      onChange={(e) => setShopReportData({ ...shopReportData, saleType: e.target.value })}
                    >
                      <option value="both">Both (Primary & Secondary)</option>
                      <option value="primary">Primary</option>
                      <option value="secondary">Secondary</option>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="start-date-shop">Start Date *</Label>
                    <Input
                      id="start-date-shop"
                      type="date"
                      value={shopReportData.startDate}
                      onChange={(e) => setShopReportData({ ...shopReportData, startDate: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="end-date-shop">End Date *</Label>
                    <Input
                      id="end-date-shop"
                      type="date"
                      value={shopReportData.endDate}
                      onChange={(e) => setShopReportData({ ...shopReportData, endDate: e.target.value })}
                    />
                  </div>
                </div>

                <Button
                  onClick={handleGenerateShopReport}
                  className="bg-[#433228] hover:bg-[#5a4238] text-white"
                >
                  Generate Report
                </Button>

                {selectedShopReport && (
                  <div className="mt-6">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="font-semibold text-lg">Report Results</h3>
                      <Button variant="outline" size="sm">
                        <Download className="h-4 w-4 mr-2" />
                        Export
                      </Button>
                    </div>

                    {(shopReportData.saleType === 'primary' || shopReportData.saleType === 'both') && (
                      <div className="mb-6">
                        <h4 className="font-semibold mb-2">Primary Sales</h4>
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Item</TableHead>
                              <TableHead>Quantity</TableHead>
                              <TableHead>MRP (Shop Value)</TableHead>
                              <TableHead>Total Value</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {selectedShopReport.primary.map((item, index) => (
                              <TableRow key={index}>
                                <TableCell className="font-medium">{item.item}</TableCell>
                                <TableCell>{item.quantity}</TableCell>
                                <TableCell>₹{item.mrp}</TableCell>
                                <TableCell>₹{item.value.toLocaleString('en-IN')}</TableCell>
                              </TableRow>
                            ))}
                            <TableRow className="font-semibold">
                              <TableCell>Total</TableCell>
                              <TableCell>
                                {selectedShopReport.primary.reduce((sum, item) => sum + item.quantity, 0)}
                              </TableCell>
                              <TableCell>-</TableCell>
                              <TableCell>
                                ₹{selectedShopReport.primary.reduce((sum, item) => sum + item.value, 0).toLocaleString('en-IN')}
                              </TableCell>
                            </TableRow>
                          </TableBody>
                        </Table>
                      </div>
                    )}

                    {(shopReportData.saleType === 'secondary' || shopReportData.saleType === 'both') && (
                      <div>
                        <h4 className="font-semibold mb-2">Secondary Sales</h4>
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Item</TableHead>
                              <TableHead>Quantity</TableHead>
                              <TableHead>MRP (Shop Value)</TableHead>
                              <TableHead>Total Value</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {selectedShopReport.secondary.map((item, index) => (
                              <TableRow key={index}>
                                <TableCell className="font-medium">{item.item}</TableCell>
                                <TableCell>{item.quantity}</TableCell>
                                <TableCell>₹{item.mrp}</TableCell>
                                <TableCell>₹{item.value.toLocaleString('en-IN')}</TableCell>
                              </TableRow>
                            ))}
                            <TableRow className="font-semibold">
                              <TableCell>Total</TableCell>
                              <TableCell>
                                {selectedShopReport.secondary.reduce((sum, item) => sum + item.quantity, 0)}
                              </TableCell>
                              <TableCell>-</TableCell>
                              <TableCell>
                                ₹{selectedShopReport.secondary.reduce((sum, item) => sum + item.value, 0).toLocaleString('en-IN')}
                              </TableCell>
                            </TableRow>
                          </TableBody>
                        </Table>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

export default SuperStockistReports
