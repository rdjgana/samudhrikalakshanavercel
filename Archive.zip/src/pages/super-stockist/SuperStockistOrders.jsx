import { useState, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Input } from '../../components/ui/input'
import { Label } from '../../components/ui/label'
import { Select } from '../../components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../../components/ui/table'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../../components/ui/dialog'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../components/ui/tabs'
import { Plus, Eye, Check, X, Edit } from 'lucide-react'
import { MOCK_PRODUCTS, COSMETICS_CATEGORIES, getProductsByCategory } from '../../data/mockData'

// Mock Factory Stock - Convert MOCK_PRODUCTS to factory stock format with cases
// Each product has SS Billing Value (Basic price), available cases, and pieces per case
const getPiecesPerCase = (product) => {
  // Different products have different pieces per case
  if (product.category === 'Personal Care') {
    return product.name === 'Soap' ? 60 : 24 // Soap: 60 pieces, others: 24 pieces
  } else if (product.category === 'Hair Care') {
    return 24 // Hair care products: 24 pieces per case
  } else if (product.category === 'Body Care') {
    return product.name === 'Body Lotion' || product.name === 'Body Oil' ? 12 : 24 // Lotions/Oils: 12, others: 24
  } else {
    return 12 // Face Care: 12 pieces per case
  }
}

const MOCK_FACTORY_STOCK = MOCK_PRODUCTS.map((product) => ({
  id: product.id,
  name: product.name,
  category: product.category,
  price: product.price, // SS Billing Value (Basic)
  availableCases: Math.floor(Math.random() * 100) + 50, // Random between 50-150 cases
  piecesPerCase: getPiecesPerCase(product),
}))

const MOCK_DISTRIBUTORS = [
  { id: 1, name: 'Shraam', area: 'Sivakasi' },
  { id: 2, name: 'Raj Distributors', area: 'Madurai' },
  { id: 3, name: 'Kumar Agencies', area: 'Coimbatore' },
]

// Mock Distributor Orders - Using actual product names from MOCK_PRODUCTS
const MOCK_DISTRIBUTOR_ORDERS = [
  {
    id: 1,
    distributorId: 1,
    distributorName: 'Shraam',
    area: 'Sivakasi',
    items: [
      { productId: 13, productName: 'Soap', quantity: 5, value: 15000 },
      { productId: 14, productName: 'Hand Wash', quantity: 3, value: 10800 },
    ],
    totalValue: 25800,
    status: 'pending',
    createdAt: '2026-01-28T10:00:00Z',
  },
  {
    id: 2,
    distributorId: 2,
    distributorName: 'Raj Distributors',
    area: 'Madurai',
    items: [
      { productId: 1, productName: 'Face Wash', quantity: 2, value: 12000 },
      { productId: 2, productName: 'Face Cream', quantity: 1, value: 5400 },
    ],
    totalValue: 17400,
    status: 'pending',
    createdAt: '2026-01-27T14:30:00Z',
  },
]

const SuperStockistOrders = () => {
  const [activeTab, setActiveTab] = useState('create')
  const [showCreateDialog, setShowCreateDialog] = useState(false)
  const [showViewDialog, setShowViewDialog] = useState(false)
  const [selectedDistributor, setSelectedDistributor] = useState('')
  const [selectedArea, setSelectedArea] = useState('')
  const [selectedOrder, setSelectedOrder] = useState(null)
  const [createOrderData, setCreateOrderData] = useState({
    category: '',
    products: {}, // { productId: { quantity: cases, price: ssBillingValue } }
  })

  const handleCreateOrder = () => {
    // Validate and create order
    if (!createOrderData.category) {
      alert('Please select a category')
      return
    }
    const selectedProducts = Object.keys(createOrderData.products)
    if (selectedProducts.length === 0) {
      alert('Please select at least one product')
      return
    }
    
    // Here you would dispatch an action to create the order
    alert('Order created successfully!')
    setShowCreateDialog(false)
    setCreateOrderData({ category: '', products: {} })
  }

  const handleViewOrders = () => {
    if (!selectedDistributor || !selectedArea) {
      alert('Please select Distributor and Area')
      return
    }
    setShowViewDialog(true)
  }

  const handleAcceptOrder = (orderId) => {
    if (confirm('Are you sure you want to accept this order? This will deduct stock from SS Stock.')) {
      alert('Order accepted successfully! Stock deducted.')
      // Update order status
    }
  }

  const handleModifyOrder = (order) => {
    setSelectedOrder(order)
    // Open modify dialog
    alert('Modify order functionality - Open edit dialog')
  }

  const handleRejectOrder = (orderId) => {
    if (confirm('Are you sure you want to reject this order?')) {
      alert('Order rejected successfully!')
      // Update order status
    }
  }

  const filteredOrders = selectedDistributor && selectedArea
    ? MOCK_DISTRIBUTOR_ORDERS.filter(
        order => order.distributorId === parseInt(selectedDistributor) && order.area === selectedArea
      )
    : []

  // Get products for selected category from factory stock
  const categoryProducts = createOrderData.category
    ? MOCK_FACTORY_STOCK.filter(p => p.category === createOrderData.category)
    : []

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Order Management</h1>
        <p className="text-gray-600 mt-2">Create orders from factory and manage distributor orders</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="create">Create Order (Purchase from Factory)</TabsTrigger>
          <TabsTrigger value="view">View Order (Distributor Fulfillment)</TabsTrigger>
        </TabsList>

        {/* Create Order Tab */}
        <TabsContent value="create">
          <Card>
            <CardHeader>
              <CardTitle>Create Order - Purchase from Factory</CardTitle>
              <CardDescription>Select products from factory stock and place order</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="category">Product Category *</Label>
                  <Select
                    id="category"
                    value={createOrderData.category}
                    onChange={(e) => {
                      setCreateOrderData({ ...createOrderData, category: e.target.value, products: {} })
                    }}
                  >
                    <option value="">Select Category</option>
                    {COSMETICS_CATEGORIES.map((category) => (
                      <option key={category.id} value={category.name}>
                        {category.name}
                      </option>
                    ))}
                  </Select>
                </div>

                {createOrderData.category && (
                  <div className="space-y-4">
                    <h3 className="font-semibold">Available Products (Factory Stock)</h3>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Product Name</TableHead>
                          <TableHead>SS Billing Value (Basic)</TableHead>
                          <TableHead>Available Cases</TableHead>
                          <TableHead>Pieces per Case</TableHead>
                          <TableHead>Order Quantity (Cases)</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {categoryProducts.map((product) => (
                          <TableRow key={product.id}>
                            <TableCell className="font-medium">{product.name}</TableCell>
                            <TableCell>₹{product.price}</TableCell>
                            <TableCell>{product.availableCases}</TableCell>
                            <TableCell>{product.piecesPerCase} pieces</TableCell>
                            <TableCell>
                              <Input
                                type="number"
                                min="0"
                                max={product.availableCases}
                                value={createOrderData.products[product.id]?.quantity || ''}
                                onChange={(e) => {
                                  const quantity = parseInt(e.target.value) || 0
                                  setCreateOrderData({
                                    ...createOrderData,
                                    products: {
                                      ...createOrderData.products,
                                      [product.id]: {
                                        quantity,
                                        price: product.price,
                                        name: product.name,
                                      },
                                    },
                                  })
                                }}
                                className="w-24"
                              />
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>

                    {Object.keys(createOrderData.products).length > 0 && (
                      <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                        <h4 className="font-semibold mb-2">Order Summary</h4>
                        {Object.entries(createOrderData.products).map(([productId, data]) => {
                          if (!data.quantity) return null
                          const product = categoryProducts.find(p => p.id === parseInt(productId))
                          return (
                            <div key={productId} className="flex justify-between text-sm">
                              <span>{data.name} - {data.quantity} case(s)</span>
                              <span>₹{(data.quantity * data.price * product.piecesPerCase).toLocaleString('en-IN')}</span>
                            </div>
                          )
                        })}
                        <div className="mt-2 pt-2 border-t flex justify-between font-semibold">
                          <span>Total Value:</span>
                          <span>
                            ₹{Object.entries(createOrderData.products).reduce((sum, [productId, data]) => {
                              if (!data.quantity) return sum
                              const product = categoryProducts.find(p => p.id === parseInt(productId))
                              return sum + (data.quantity * data.price * product.piecesPerCase)
                            }, 0).toLocaleString('en-IN')}
                          </span>
                        </div>
                      </div>
                    )}

                    <Button
                      onClick={handleCreateOrder}
                      className="bg-[#433228] hover:bg-[#5a4238] text-white"
                    >
                      Complete Order
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* View Order Tab */}
        <TabsContent value="view">
          <Card>
            <CardHeader>
              <CardTitle>View Orders - Distributor Fulfillment</CardTitle>
              <CardDescription>View and manage orders received from distributors</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="distributor">Distributor Name *</Label>
                    <Select
                      id="distributor"
                      value={selectedDistributor}
                      onChange={(e) => {
                        setSelectedDistributor(e.target.value)
                        setSelectedArea('')
                      }}
                    >
                      <option value="">Select Distributor</option>
                      {MOCK_DISTRIBUTORS.map((dist) => (
                        <option key={dist.id} value={dist.id}>
                          {dist.name}
                        </option>
                      ))}
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="area">Area *</Label>
                    <Select
                      id="area"
                      value={selectedArea}
                      onChange={(e) => setSelectedArea(e.target.value)}
                      disabled={!selectedDistributor}
                    >
                      <option value="">Select Area</option>
                      {selectedDistributor && MOCK_DISTRIBUTORS
                        .find(d => d.id === parseInt(selectedDistributor))
                        ?.area && (
                        <option value={MOCK_DISTRIBUTORS.find(d => d.id === parseInt(selectedDistributor)).area}>
                          {MOCK_DISTRIBUTORS.find(d => d.id === parseInt(selectedDistributor)).area}
                        </option>
                      )}
                    </Select>
                  </div>
                </div>

                <Button
                  onClick={handleViewOrders}
                  disabled={!selectedDistributor || !selectedArea}
                  className="bg-[#433228] hover:bg-[#5a4238] text-white"
                >
                  View Orders
                </Button>

                {filteredOrders.length > 0 && (
                  <div className="mt-6">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Order Date</TableHead>
                          <TableHead>Items</TableHead>
                          <TableHead>Quantity</TableHead>
                          <TableHead>Value</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredOrders.map((order) => (
                          <TableRow key={order.id}>
                            <TableCell>
                              {new Date(order.createdAt).toLocaleDateString()}
                            </TableCell>
                            <TableCell>
                              {order.items.map(item => item.productName).join(', ')}
                            </TableCell>
                            <TableCell>
                              {order.items.reduce((sum, item) => sum + item.quantity, 0)} cases
                            </TableCell>
                            <TableCell>₹{order.totalValue.toLocaleString('en-IN')}</TableCell>
                            <TableCell>
                              <div className="flex gap-2">
                                <Button
                                  size="sm"
                                  onClick={() => handleAcceptOrder(order.id)}
                                  className="bg-green-600 hover:bg-green-700 text-white"
                                >
                                  <Check className="h-4 w-4" />
                                </Button>
                                <Button
                                  size="sm"
                                  onClick={() => handleModifyOrder(order)}
                                  className="bg-blue-600 hover:bg-blue-700 text-white"
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button
                                  size="sm"
                                  onClick={() => handleRejectOrder(order.id)}
                                  className="bg-red-600 hover:bg-red-700 text-white"
                                >
                                  <X className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}

                {selectedDistributor && selectedArea && filteredOrders.length === 0 && (
                  <p className="text-center text-gray-500 py-8">No pending orders found</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

export default SuperStockistOrders
