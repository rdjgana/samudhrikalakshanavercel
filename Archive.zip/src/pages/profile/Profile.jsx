import { useSelector } from 'react-redux'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card'
import { User, Mail, Phone, MapPin, Building, Briefcase } from 'lucide-react'

const Profile = () => {
  const { user } = useSelector((state) => state.auth)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">My Profile</h1>
        <p className="text-gray-600 mt-2">View your profile information</p>
      </div>

      {/* Profile Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-4">
            <div className="h-20 w-20 rounded-full bg-[#433228] flex items-center justify-center text-white font-semibold text-2xl shadow-lg">
              {user?.name ? (
                user.name.split(' ').length >= 2
                  ? `${user.name.split(' ')[0][0]}${user.name.split(' ')[user.name.split(' ').length - 1][0]}`.toUpperCase()
                  : user.name.substring(0, 2).toUpperCase()
              ) : user?.username ? user.username.substring(0, 2).toUpperCase() : 'U'}
            </div>
            <div>
              <CardTitle className="text-2xl">{user?.name || user?.username || 'User'}</CardTitle>
              <CardDescription className="text-base mt-1">{user?.role || 'Employee'}</CardDescription>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Personal Information */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Personal Information
          </CardTitle>
          <CardDescription>Your personal details and contact information</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <User className="h-4 w-4" />
                Full Name
              </div>
              <p className="font-semibold text-gray-900">{user?.name || 'N/A'}</p>
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Briefcase className="h-4 w-4" />
                Employee Code
              </div>
              <p className="font-semibold text-gray-900">{user?.code || user?.username || 'N/A'}</p>
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Mail className="h-4 w-4" />
                Email Address
              </div>
              <p className="font-semibold text-gray-900">{user?.email || 'N/A'}</p>
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Phone className="h-4 w-4" />
                Phone Number
              </div>
              <p className="font-semibold text-gray-900">{user?.phone || 'N/A'}</p>
            </div>
            {user?.role && (
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Building className="h-4 w-4" />
                  Role
                </div>
                <p className="font-semibold text-gray-900">{user.role}</p>
              </div>
            )}
            {user?.area && (
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <MapPin className="h-4 w-4" />
                  Area/District
                </div>
                <p className="font-semibold text-gray-900">{user.area}</p>
              </div>
            )}
            {user?.shopName && (
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Building className="h-4 w-4" />
                  Shop Name
                </div>
                <p className="font-semibold text-gray-900">{user.shopName}</p>
              </div>
            )}
            {user?.supervisorId && (
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <User className="h-4 w-4" />
                  Supervisor ID
                </div>
                <p className="font-semibold text-gray-900">{user.supervisorId}</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Additional Information */}
      {(user?.address || user?.dateOfJoining || user?.qualification) && (
        <Card>
          <CardHeader>
            <CardTitle>Additional Information</CardTitle>
            <CardDescription>Additional details about your profile</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {user?.address && (
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <MapPin className="h-4 w-4" />
                    Address
                  </div>
                  <p className="font-semibold text-gray-900">{user.address}</p>
                </div>
              )}
              {user?.dateOfJoining && (
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Briefcase className="h-4 w-4" />
                    Date of Joining
                  </div>
                  <p className="font-semibold text-gray-900">
                    {new Date(user.dateOfJoining).toLocaleDateString()}
                  </p>
                </div>
              )}
              {user?.qualification && (
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Briefcase className="h-4 w-4" />
                    Qualification
                  </div>
                  <p className="font-semibold text-gray-900">{user.qualification}</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

export default Profile
