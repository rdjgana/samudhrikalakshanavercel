import { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import { loginUser, dummyLogin, dummySupervisorLogin, dummyPromoterLogin, dummySuperStockistLogin, dummyDistributorLogin } from '../../store/slices/authSlice'
import { MOCK_SHOPS } from '../../data/mockData'
import { Button } from '../../components/ui/button'
import { Input } from '../../components/ui/input'
import { Label } from '../../components/ui/label'
import { Select } from '../../components/ui/select'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card'
import { User, Lock } from 'lucide-react'

const ROLES = [
  { value: 'RSM', label: 'RSM (Regional Sales Manager)', dashboard: '/dashboard' },
  { value: 'Supervisor', label: 'Supervisor', dashboard: '/supervisor/dashboard' },
  { value: 'Promoter', label: 'Promoter', dashboard: '/promoter/dashboard' },
  { value: 'Super Stockist', label: 'Super Stockist (SS)', dashboard: '/super-stockist/dashboard' },
  { value: 'Distributor', label: 'Distributor', dashboard: '/distributor/dashboard' },
]

const Login = () => {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [selectedRole, setSelectedRole] = useState('')
  const [selectedShop, setSelectedShop] = useState('')
  const [logoError, setLogoError] = useState(false)
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const { loading, error } = useSelector((state) => state.auth)

  const handleSubmit = async (e) => {
    e.preventDefault()
    
    if (!selectedRole) {
      alert('Please select your role')
      return
    }

    // For Promoter role, shop name is required instead of username/password
    if (selectedRole === 'Promoter') {
      if (!selectedShop) {
        alert('Please select your shop name')
        return
      }
      const shop = MOCK_SHOPS.find(s => s.id === parseInt(selectedShop))
      dispatch(dummyPromoterLogin({ shopId: selectedShop, shopName: shop?.name }))
      setTimeout(() => {
        navigate('/promoter/dashboard', { replace: true })
      }, 100)
    } else if (selectedRole === 'Supervisor') {
      if (!username || !password) {
        alert('Please enter username and password')
        return
      }
      dispatch(dummySupervisorLogin())
      setTimeout(() => {
        navigate('/supervisor/dashboard', { replace: true })
      }, 100)
    } else if (selectedRole === 'RSM') {
      // For RSM - use regular dummy login with role
      if (!username || !password) {
        alert('Please enter username and password')
        return
      }
      dispatch(dummyLogin({ role: selectedRole }))
      setTimeout(() => {
        navigate('/dashboard', { replace: true })
      }, 100)
    } else if (selectedRole === 'Super Stockist') {
      // For Super Stockist
      if (!username || !password) {
        alert('Please enter username and password')
        return
      }
      dispatch(dummySuperStockistLogin())
      setTimeout(() => {
        navigate('/super-stockist/dashboard', { replace: true })
      }, 100)
    } else if (selectedRole === 'Distributor') {
      // For Distributor
      if (!username || !password) {
        alert('Please enter username and password')
        return
      }
      dispatch(dummyDistributorLogin())
      setTimeout(() => {
        navigate('/distributor/dashboard', { replace: true })
      }, 100)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="space-y-1 text-center">
          <div className="mx-auto mb-4 w-20 h-20 flex items-center justify-center">
            {!logoError ? (
              <img 
                src="/logo.png" 
                alt="Logo" 
                className="h-20 w-20 object-contain"
                onError={() => setLogoError(true)}
              />
            ) : (
              <div className="w-16 h-16 bg-[#433228] rounded-full flex items-center justify-center">
                <User className="h-8 w-8 text-white" />
              </div>
            )}
          </div>
          <CardTitle className="text-2xl font-bold">RSM ERP System</CardTitle>
          <CardDescription>
            Role-Based Login System
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Role Selection */}
            <div className="space-y-2">
              <Label htmlFor="role">Select Your Role *</Label>
              <Select
                id="role"
                value={selectedRole}
                onChange={(e) => {
                  setSelectedRole(e.target.value)
                  setSelectedShop('')
                  setUsername('')
                  setPassword('')
                }}
                required
              >
                <option value="">Choose your role</option>
                {ROLES.map((role) => (
                  <option key={role.value} value={role.value}>
                    {role.label}
                  </option>
                ))}
              </Select>
            </div>

            {/* Shop Name Selection for Promoter */}
            {selectedRole === 'Promoter' && (
              <div className="space-y-2">
                <Label htmlFor="shop">Select Shop Name *</Label>
                <Select
                  id="shop"
                  value={selectedShop}
                  onChange={(e) => setSelectedShop(e.target.value)}
                  required
                >
                  <option value="">Choose your shop</option>
                  {MOCK_SHOPS.map((shop) => (
                    <option key={shop.id} value={shop.id}>
                      {shop.name} - {shop.address}
                    </option>
                  ))}
                </Select>
              </div>
            )}

            {/* Username - Hidden for Promoter */}
            {selectedRole !== 'Promoter' && (
              <div className="space-y-2">
                <Label htmlFor="username">Username *</Label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    id="username"
                    type="text"
                    placeholder="Enter your username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="pl-10"
                    required
                  />
                </div>
              </div>
            )}

            {/* Password - Hidden for Promoter */}
            {selectedRole !== 'Promoter' && (
              <div className="space-y-2">
                <Label htmlFor="password">Password *</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    id="password"
                    type="password"
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10"
                    required
                  />
                </div>
              </div>
            )}

            {error && (
              <div className="text-sm text-destructive bg-destructive/10 p-3 rounded-md">
                {error}
              </div>
            )}

            <Button 
              type="submit" 
              className="w-full bg-[#433228] hover:bg-[#5a4238] text-white" 
              disabled={loading || !selectedRole || (selectedRole === 'Promoter' && !selectedShop) || (selectedRole !== 'Promoter' && (!username || !password))}
            >
              {loading ? 'Logging in...' : 'Login'}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}

export default Login
