import { useState, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import {
  fetchHierarchy,
  fetchUserDetails,
  assignTarget,
  clearError,
  clearSuccessMessage,
} from '../../store/slices/targetsSlice'
import { Button } from '../../components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card'
import { Input } from '../../components/ui/input'
import { Label } from '../../components/ui/label'
import { Select } from '../../components/ui/select'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '../../components/ui/dialog'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../components/ui/tabs'
import { MOCK_SS_LIST, MOCK_HIERARCHY, MOCK_SUPERVISOR_PROMOTERS } from '../../data/mockData'

const Targets = () => {
  const dispatch = useDispatch()
  const { user } = useSelector((state) => state.auth)
  const { hierarchy, selectedUser, loading, error, successMessage, assignedTargets } = useSelector((state) => state.targets)
  
  const isSupervisor = user?.role === 'Supervisor'
  const supervisorId = user?.supervisorId || 1 // Default to supervisor ID 1 for mock data
  
  // For Supervisor, get assigned promoters and distributors
  const supervisorPromoters = isSupervisor ? MOCK_SUPERVISOR_PROMOTERS : []
  const supervisorDistributors = isSupervisor 
    ? (MOCK_HIERARCHY.distributors || []).filter(dist => dist.supervisorId === supervisorId)
    : []

  const [selectedRole, setSelectedRole] = useState('') // 'asm', 'so', 'supervisor', 'ss', 'distributor', 'promoter'
  const [selectedUserId, setSelectedUserId] = useState('')
  const [selectedMemberType, setSelectedMemberType] = useState('') // For Supervisor: 'promoter' or 'distributor'
  const [targetData, setTargetData] = useState({
    primary: '', // Purchase amount
    secondary: '', // Sales amount
    month: new Date().toISOString().slice(0, 7),
  })
  const [showAssignDialog, setShowAssignDialog] = useState(false)
  const [editingTarget, setEditingTarget] = useState(null) // Store target being edited

  useEffect(() => {
    dispatch(fetchHierarchy())
  }, [dispatch])

  // Reset when member type changes for Supervisor
  useEffect(() => {
    if (isSupervisor && selectedMemberType) {
      setSelectedRole(selectedMemberType) // Set role to match member type
      setSelectedUserId('') // Reset user selection
    }
  }, [selectedMemberType, isSupervisor])

  useEffect(() => {
    if (selectedUserId) {
      dispatch(fetchUserDetails(parseInt(selectedUserId)))
    }
  }, [selectedUserId, dispatch])

  const getUsersByRole = () => {
    // For Supervisor, return based on selectedMemberType
    if (isSupervisor) {
      if (selectedMemberType === 'promoter') {
        return supervisorPromoters
      } else if (selectedMemberType === 'distributor') {
        return supervisorDistributors
      }
      return []
    }

    // For RSM/ASM/SO, use original logic
    switch (selectedRole) {
      case 'asm':
        return hierarchy.asms || []
      case 'so':
        return hierarchy.sos || []
      case 'supervisor':
        return hierarchy.supervisors || []
      case 'distributor':
        return hierarchy.distributors || []
      case 'promoter':
        return hierarchy.promoters || []
      case 'ss':
        return MOCK_SS_LIST || []
      default:
        return []
    }
  }

  const handleAssign = async () => {
    // Validate that at least one target value is entered
    if (!targetData.primary && !targetData.secondary) {
      alert('Please enter at least one target value (Primary or Secondary)')
      return
    }

    // For Supervisor, check memberType and userId
    if (isSupervisor) {
      if (!selectedMemberType || !selectedUserId) {
        alert('Please select member type and member')
        return
      }
    } else {
      if (!selectedRole || !selectedUserId) {
        alert('Please select a role and user')
        return
      }
    }

    // Determine role for assignment (for Supervisor, use memberType as role)
    const assignmentRole = isSupervisor ? selectedMemberType : selectedRole

    const result = await dispatch(
      assignTarget({
        id: editingTarget?.id, // Include ID if editing - this is crucial for update
        role: assignmentRole,
        userId: selectedUserId,
        userName: getSelectedUserName(),
        assignedAt: editingTarget?.assignedAt, // Preserve original assignedAt when editing
        ...targetData,
      })
    )

    if (assignTarget.fulfilled.match(result)) {
      setShowAssignDialog(false)
      setEditingTarget(null)
      // Reset form
      if (isSupervisor) {
        setSelectedMemberType('')
      } else {
        setSelectedRole('')
      }
      setSelectedUserId('')
      setTargetData({
        primary: '',
        secondary: '',
        month: new Date().toISOString().slice(0, 7),
      })
      // Clear success message after 5 seconds
      setTimeout(() => {
        dispatch(clearSuccessMessage())
      }, 5000)
    }
  }

  const handleEdit = (target) => {
    // Pre-fill form with target data
    setEditingTarget(target)
    
    if (isSupervisor) {
      // For Supervisor, set memberType based on target role
      setSelectedMemberType(target.role || '')
      setSelectedRole(target.role || '') // Also set role for compatibility
    } else {
      setSelectedRole(target.role || '')
    }
    
    // Convert userId to string if it's a number
    setSelectedUserId(target.userId ? String(target.userId) : '')
    setTargetData({
      primary: target.primary || '',
      secondary: target.secondary || '',
      month: target.month || new Date().toISOString().slice(0, 7),
    })
    setShowAssignDialog(true)
  }

  const getSelectedUserName = () => {
    if (isSupervisor) {
      if (!selectedMemberType || !selectedUserId) return 'Unknown Member'
      
      if (selectedMemberType === 'promoter') {
        const prom = supervisorPromoters.find(p => p.id === parseInt(selectedUserId))
        return prom?.name || 'Selected Promoter'
      } else if (selectedMemberType === 'distributor') {
        const dist = supervisorDistributors.find(d => d.id === parseInt(selectedUserId))
        return dist?.name || 'Selected Distributor'
      }
      return 'Unknown Member'
    }
    
    if (!selectedRole || !selectedUserId) return 'Unknown User'
    
    switch (selectedRole) {
      case 'asm': {
        const asm = hierarchy.asms?.find(a => a.id === parseInt(selectedUserId))
        return asm?.name || 'Selected ASM'
      }
      case 'so': {
        const so = hierarchy.sos?.find(s => s.id === parseInt(selectedUserId))
        return so?.name || 'Selected SO'
      }
      case 'supervisor': {
        const sup = hierarchy.supervisors?.find(s => s.id === parseInt(selectedUserId))
        return sup?.name || 'Selected Supervisor'
      }
      case 'distributor': {
        const dist = hierarchy.distributors?.find(d => d.id === parseInt(selectedUserId))
        return dist?.name || 'Selected Distributor'
      }
      case 'promoter': {
        const prom = hierarchy.promoters?.find(p => p.id === parseInt(selectedUserId))
        return prom?.name || 'Selected Promoter'
      }
      case 'ss': {
        const ss = MOCK_SS_LIST.find(s => s.id === parseInt(selectedUserId))
        return ss?.name || 'Selected SS'
      }
      default:
        return 'Selected User'
    }
  }

  // Mock purchase amounts for display
  const mockPurchaseAmounts = {
    level1: {
      ss_1: 1250000, // SS 1 Purchase from Factory
      ss_2: 980000,
      ss_3: 1100000,
      ss_4: 850000,
      ss_5: 920000,
    },
    level2: {
      dist_1: 850000, // Distributor 1 Purchase from SS
      dist_2: 720000,
      dist_3: 680000,
      dist_4: 550000,
      dist_5: 620000,
      dist_6: 480000,
      dist_7: 750000,
    },
    level3: {
      shop_1: 450000, // Shops under Distributor 1 Purchase
      shop_2: 380000,
      shop_3: 420000,
      shop_4: 320000,
      shop_5: 350000,
      shop_6: 280000,
      shop_7: 480000,
    },
    level4: {
      // New Shops with one day purchase amounts
      distributor_1: [
        { id: 1, name: 'Beauty Zone T Nagar', oneDayAmount: 25000 },
        { id: 2, name: 'Glow Beauty Parlour', oneDayAmount: 22000 },
        { id: 3, name: 'Radiance Cosmetics', oneDayAmount: 28000 },
        { id: 4, name: 'Beauty World', oneDayAmount: 20000 },
        { id: 5, name: 'Cosmetic Corner', oneDayAmount: 24000 },
      ],
      distributor_2: [
        { id: 6, name: 'Glow Shop', oneDayAmount: 18000 },
        { id: 7, name: 'Beauty Hub', oneDayAmount: 21000 },
        { id: 8, name: 'Cosmetic Store', oneDayAmount: 19000 },
        { id: 9, name: 'Radiance Beauty', oneDayAmount: 23000 },
      ],
      distributor_3: [
        { id: 10, name: 'Beauty Palace', oneDayAmount: 26000 },
        { id: 11, name: 'Glow Zone', oneDayAmount: 24000 },
        { id: 12, name: 'Cosmetic World', oneDayAmount: 22000 },
      ],
      distributor_4: [
        { id: 13, name: 'Beauty Mart', oneDayAmount: 15000 },
        { id: 14, name: 'Glow Mart', oneDayAmount: 17000 },
      ],
      distributor_5: [
        { id: 15, name: 'Radiance Shop', oneDayAmount: 20000 },
        { id: 16, name: 'Beauty Point', oneDayAmount: 18000 },
        { id: 17, name: 'Cosmetic Point', oneDayAmount: 19000 },
      ],
      distributor_6: [
        { id: 18, name: 'Beauty Express', oneDayAmount: 16000 },
      ],
      distributor_7: [
        { id: 19, name: 'Glow Express', oneDayAmount: 25000 },
        { id: 20, name: 'Radiance Express', oneDayAmount: 27000 },
        { id: 21, name: 'Beauty Plus', oneDayAmount: 24000 },
      ],
    },
    // Secondary Target amounts
    secondary: {
      level1: {
        ss_1: 1100000, // SS 1 Sale to Distributor
        ss_2: 850000,
        ss_3: 980000,
        ss_4: 750000,
        ss_5: 820000,
      },
      level2: {
        dist_1: 720000, // Distributor 1 Sale to Shop
        dist_2: 600000,
        dist_3: 580000,
        dist_4: 480000,
        dist_5: 520000,
        dist_6: 400000,
        dist_7: 650000,
      },
      level3: {
        shop_1: 380000, // Shops under Distributor 1 Sale to Customer
        shop_2: 320000,
        shop_3: 350000,
        shop_4: 280000,
        shop_5: 300000,
        shop_6: 240000,
        shop_7: 420000,
      },
      level4: {
        // New Shops with sales amounts
        distributor_1: [
          { id: 1, name: 'Beauty Zone T Nagar', salesAmount: 22000 },
          { id: 2, name: 'Glow Beauty Parlour', salesAmount: 20000 },
          { id: 3, name: 'Radiance Cosmetics', salesAmount: 25000 },
          { id: 4, name: 'Beauty World', salesAmount: 18000 },
          { id: 5, name: 'Cosmetic Corner', salesAmount: 21000 },
        ],
        distributor_2: [
          { id: 6, name: 'Glow Shop', salesAmount: 16000 },
          { id: 7, name: 'Beauty Hub', salesAmount: 19000 },
          { id: 8, name: 'Cosmetic Store', salesAmount: 17000 },
          { id: 9, name: 'Radiance Beauty', salesAmount: 20000 },
        ],
        distributor_3: [
          { id: 10, name: 'Beauty Palace', salesAmount: 23000 },
          { id: 11, name: 'Glow Zone', salesAmount: 21000 },
          { id: 12, name: 'Cosmetic World', salesAmount: 19000 },
        ],
        distributor_4: [
          { id: 13, name: 'Beauty Mart', salesAmount: 13000 },
          { id: 14, name: 'Glow Mart', salesAmount: 15000 },
        ],
        distributor_5: [
          { id: 15, name: 'Radiance Shop', salesAmount: 18000 },
          { id: 16, name: 'Beauty Point', salesAmount: 16000 },
          { id: 17, name: 'Cosmetic Point', salesAmount: 17000 },
        ],
        distributor_6: [
          { id: 18, name: 'Beauty Express', salesAmount: 14000 },
        ],
        distributor_7: [
          { id: 19, name: 'Glow Express', salesAmount: 22000 },
          { id: 20, name: 'Radiance Express', salesAmount: 24000 },
          { id: 21, name: 'Beauty Plus', salesAmount: 21000 },
        ],
      },
    },
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">My Target</h1>
        <p className="text-gray-600 mt-2">View and manage primary purchase targets</p>
      </div>

      <Tabs defaultValue="my-target" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="my-target">My Target</TabsTrigger>
          <TabsTrigger value="assign-target">Assign Target</TabsTrigger>
        </TabsList>

        {/* My Target Tab */}
        <TabsContent value="my-target">
          <Tabs defaultValue="primary" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="primary">Primary Targets</TabsTrigger>
              <TabsTrigger value="secondary">Secondary Targets</TabsTrigger>
            </TabsList>

            {/* Primary Targets Tab */}
            <TabsContent value="primary">
              <Card>
                <CardHeader>
                  <CardTitle>Primary Purchase Targets</CardTitle>
                  <CardDescription>Purchase levels with amount values for SS, Distributor, and Shop</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
              {/* Level 1: SS Purchase from Factory */}
              <div className="border rounded-lg p-4">
                <h3 className="font-semibold text-lg mb-4">Level 1: SS Purchase from Factory</h3>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {MOCK_SS_LIST.map((ss) => (
                      <div key={ss.id} className="space-y-2">
                        <Label>{ss.name}</Label>
                        <div className="flex items-center gap-2 p-3 bg-gray-50 rounded-md">
                          <span className="text-lg font-semibold text-primary">
                            ₹{mockPurchaseAmounts.level1[`ss_${ss.id}`]?.toLocaleString('en-IN') || '0'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Level 2: Distributor Purchase from SS */}
              <div className="border rounded-lg p-4">
                <h3 className="font-semibold text-lg mb-4">Level 2: Distributor Purchase from SS</h3>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {MOCK_HIERARCHY.distributors.map((dist) => (
                      <div key={dist.id} className="space-y-2">
                        <Label>{dist.name}</Label>
                        <div className="flex items-center gap-2 p-3 bg-gray-50 rounded-md">
                          <span className="text-lg font-semibold text-primary">
                            ₹{mockPurchaseAmounts.level2[`dist_${dist.id}`]?.toLocaleString('en-IN') || '0'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Level 3: Shop Purchase from Distributor */}
              <div className="border rounded-lg p-4">
                <h3 className="font-semibold text-lg mb-4">Level 3: Shop Purchase from Distributor</h3>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {MOCK_HIERARCHY.distributors.map((dist) => (
                      <div key={dist.id} className="space-y-2">
                        <Label>Shops under {dist.name}</Label>
                        <div className="flex items-center gap-2 p-3 bg-gray-50 rounded-md">
                          <span className="text-lg font-semibold text-primary">
                            ₹{mockPurchaseAmounts.level3[`shop_${dist.id}`]?.toLocaleString('en-IN') || '0'}
                          </span>
                        </div>
                        <p className="text-xs text-gray-500">Total Shops: {dist.shopCount}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Level 4: New Shop */}
              <div className="border rounded-lg p-4">
                <h3 className="font-semibold text-lg mb-4">Level 4: New Shop</h3>
                <div className="space-y-6">
                  {MOCK_HIERARCHY.distributors.map((dist) => {
                    const newShops = mockPurchaseAmounts.level4[`distributor_${dist.id}`] || []
                    if (newShops.length === 0) return null
                    
                    return (
                      <div key={dist.id} className="border rounded-lg p-4 bg-gray-50">
                        <h4 className="font-semibold mb-3 text-primary">{dist.name}</h4>
                        <div className="space-y-2">
                          {newShops.map((shop) => (
                            <div key={shop.id} className="flex items-center justify-between p-2 bg-white rounded border">
                              <span className="font-medium">{shop.name}</span>
                              <span className="text-lg font-semibold text-primary">
                                ₹{shop.oneDayAmount?.toLocaleString('en-IN') || '0'}
                              </span>
                            </div>
                          ))}
                          <div className="flex items-center justify-between p-2 bg-primary/10 rounded border-2 border-primary mt-2">
                            <span className="font-semibold">Total ({newShops.length} Shops)</span>
                            <span className="text-lg font-bold text-primary">
                              ₹{newShops.reduce((sum, shop) => sum + (shop.oneDayAmount || 0), 0).toLocaleString('en-IN')}
                            </span>
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Secondary Targets Tab */}
            <TabsContent value="secondary">
              <Card>
                <CardHeader>
                  <CardTitle>Secondary Sales Targets</CardTitle>
                  <CardDescription>Sales levels with amount values for SS, Distributor, Shop, and New Shops</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Level 1: SS Sale to Distributor */}
                <div className="border rounded-lg p-4 mb-4">
                  <h3 className="font-semibold text-lg mb-4">Level 1: SS Sale to Distributor</h3>
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {MOCK_SS_LIST.map((ss) => (
                        <div key={ss.id} className="space-y-2">
                          <Label>{ss.name}</Label>
                          <div className="flex items-center gap-2 p-3 bg-gray-50 rounded-md">
                            <span className="text-lg font-semibold text-primary">
                              ₹{mockPurchaseAmounts.secondary.level1[`ss_${ss.id}`]?.toLocaleString('en-IN') || '0'}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Level 2: Distributor Sale to Shop */}
                <div className="border rounded-lg p-4 mb-4">
                  <h3 className="font-semibold text-lg mb-4">Level 2: Distributor Sale to Shop</h3>
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {MOCK_HIERARCHY.distributors.map((dist) => (
                        <div key={dist.id} className="space-y-2">
                          <Label>{dist.name}</Label>
                          <div className="flex items-center gap-2 p-3 bg-gray-50 rounded-md">
                            <span className="text-lg font-semibold text-primary">
                              ₹{mockPurchaseAmounts.secondary.level2[`dist_${dist.id}`]?.toLocaleString('en-IN') || '0'}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Level 3: Shop to Customer */}
                <div className="border rounded-lg p-4 mb-4">
                  <h3 className="font-semibold text-lg mb-4">Level 3: Shop to Customer</h3>
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {MOCK_HIERARCHY.distributors.map((dist) => (
                        <div key={dist.id} className="space-y-2">
                          <Label>Shops under {dist.name}</Label>
                          <div className="flex items-center gap-2 p-3 bg-gray-50 rounded-md">
                            <span className="text-lg font-semibold text-primary">
                              ₹{mockPurchaseAmounts.secondary.level3[`shop_${dist.id}`]?.toLocaleString('en-IN') || '0'}
                            </span>
                          </div>
                          <p className="text-xs text-gray-500">Total Shops: {dist.shopCount}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Level 4: New Shop Sales Amount */}
                <div className="border rounded-lg p-4">
                  <h3 className="font-semibold text-lg mb-4">Level 4: New Shop Sales Amount</h3>
                  <div className="space-y-6">
                    {MOCK_HIERARCHY.distributors.map((dist) => {
                      const newShops = mockPurchaseAmounts.secondary.level4[`distributor_${dist.id}`] || []
                      if (newShops.length === 0) return null
                      
                      return (
                        <div key={dist.id} className="border rounded-lg p-4 bg-gray-50">
                          <h4 className="font-semibold mb-3 text-primary">{dist.name}</h4>
                          <div className="space-y-2">
                            {newShops.map((shop) => (
                              <div key={shop.id} className="flex items-center justify-between p-2 bg-white rounded border">
                                <span className="font-medium">{shop.name}</span>
                                <span className="text-lg font-semibold text-primary">
                                  ₹{shop.salesAmount?.toLocaleString('en-IN') || '0'}
                                </span>
                              </div>
                            ))}
                            <div className="flex items-center justify-between p-2 bg-primary/10 rounded border-2 border-primary mt-2">
                              <span className="font-semibold">Total Sales ({newShops.length} Shops)</span>
                              <span className="text-lg font-bold text-primary">
                                ₹{newShops.reduce((sum, shop) => sum + (shop.salesAmount || 0), 0).toLocaleString('en-IN')}
                              </span>
                            </div>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </TabsContent>

        {/* Assign Target Tab */}
        <TabsContent value="assign-target">
          <Card>
            <CardHeader>
              <CardTitle>Target Assignment</CardTitle>
              <CardDescription>
                {isSupervisor 
                  ? 'Select member type (Promoter or Distributor) and assign Primary (Purchase) and Secondary (Sales) targets'
                  : 'Select role and user to assign Primary (Purchase) and Secondary (Sales) targets'
                }
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {isSupervisor ? (
                // Supervisor-specific UI: Member Type + Member Selection
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Select Member Type *</Label>
                    <Select
                      value={selectedMemberType}
                      onChange={(e) => {
                        setSelectedMemberType(e.target.value)
                        setSelectedUserId('')
                      }}
                      required
                    >
                      <option value="">Choose Member Type</option>
                      <option value="promoter">Promoter</option>
                      <option value="distributor">Distributor</option>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>
                      {selectedMemberType === 'promoter' 
                        ? 'Select Promoter *' 
                        : selectedMemberType === 'distributor'
                        ? 'Select Distributor *'
                        : 'Select Member *'
                      }
                    </Label>
                    <Select
                      value={selectedUserId}
                      onChange={(e) => setSelectedUserId(e.target.value)}
                      disabled={!selectedMemberType}
                      required
                    >
                      <option value="">
                        {selectedMemberType === 'promoter' 
                          ? 'Select Promoter' 
                          : selectedMemberType === 'distributor'
                          ? 'Select Distributor'
                          : 'Select Member Type first'
                        }
                      </option>
                      {selectedMemberType && getUsersByRole().length > 0 ? (
                        getUsersByRole().map((member) => (
                          <option key={member.id} value={member.id}>
                            {member.name} {member.code ? `(${member.code})` : ''}
                          </option>
                        ))
                      ) : (
                        <option value="" disabled>
                          {!selectedMemberType 
                            ? 'Select Member Type first' 
                            : selectedMemberType === 'promoter'
                            ? 'No promoters available'
                            : 'No distributors available'
                          }
                        </option>
                      )}
                    </Select>
                  </div>
                </div>
              ) : (
                // RSM/ASM/SO UI: Role + User Selection
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Select Role</Label>
                    <Select
                      value={selectedRole}
                      onChange={(e) => {
                        setSelectedRole(e.target.value)
                        setSelectedUserId('')
                      }}
                    >
                      <option value="">Select Role</option>
                      <option value="asm">ASM (Area Sales Manager)</option>
                      <option value="so">SO (Sales Officer)</option>
                      <option value="supervisor">Supervisor</option>
                      <option value="ss">SS (Super Stockist)</option>
                      <option value="distributor">Distributor</option>
                      <option value="promoter">Promoter</option>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Select User</Label>
                    <Select
                      value={selectedUserId}
                      onChange={(e) => setSelectedUserId(e.target.value)}
                      disabled={!selectedRole}
                    >
                      <option value="">Select User</option>
                      {selectedRole && getUsersByRole().length > 0 ? (
                        getUsersByRole().map((user) => (
                          <option key={user.id} value={user.id}>
                            {user.name} {user.code ? `(${user.code})` : ''}
                          </option>
                        ))
                      ) : (
                        <option value="" disabled>
                          {!selectedRole ? 'Select Role first' : 'No users available'}
                        </option>
                      )}
                    </Select>
                  </div>
                </div>
              )}

          {selectedUser && (
            <Card className="bg-gray-50">
              <CardContent className="pt-6">
                <h3 className="font-semibold mb-2">User Details:</h3>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-gray-600">Distributors:</p>
                    <p className="font-medium">{selectedUser.distributorCount || 0}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Shops:</p>
                    <p className="font-medium">{selectedUser.shopCount || 0}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          <div className="space-y-2">
            <Label>Month</Label>
            <Input
              type="month"
              value={targetData.month}
              onChange={(e) => setTargetData({ ...targetData, month: e.target.value })}
            />
          </div>

              <Button
                onClick={() => setShowAssignDialog(true)}
                disabled={
                  isSupervisor 
                    ? (!selectedMemberType || !selectedUserId || loading)
                    : (!selectedRole || !selectedUserId || loading)
                }
                className="w-full bg-[#433228] hover:bg-[#5a4238] text-white"
              >
                Assign Target
              </Button>
        </CardContent>
          </Card>

          <Dialog open={showAssignDialog} onOpenChange={(open) => {
            setShowAssignDialog(open)
            if (!open) {
              setEditingTarget(null)
              // Reset form when closing
              setSelectedRole('')
              setSelectedUserId('')
              setTargetData({
                primary: '',
                secondary: '',
                month: new Date().toISOString().slice(0, 7),
              })
            }
          }}>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  {editingTarget ? 'Edit Target' : 'Assign Target'} - {getSelectedUserName() || 'Select User'}
                </DialogTitle>
                <p className="text-sm text-gray-600 mt-2">
                  {selectedRole && `Role: ${selectedRole.toUpperCase()} | `}Month: {targetData.month}
                </p>
              </DialogHeader>
              <div className="space-y-6">
                {/* Role and User Selection (shown when editing, pre-filled) */}
                {editingTarget && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-gray-50 p-4 rounded-lg">
                    <div className="space-y-2">
                      <Label>Role</Label>
                      <Select
                        value={selectedRole}
                        onChange={(e) => {
                          setSelectedRole(e.target.value)
                          setSelectedUserId('')
                        }}
                      >
                        <option value="">Select Role</option>
                        <option value="asm">ASM (Area Sales Manager)</option>
                        <option value="so">SO (Sales Officer)</option>
                        <option value="supervisor">Supervisor</option>
                        <option value="ss">SS (Super Stockist)</option>
                        <option value="distributor">Distributor</option>
                        <option value="promoter">Promoter</option>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>User</Label>
                      <Select
                        value={selectedUserId}
                        onChange={(e) => setSelectedUserId(e.target.value)}
                        disabled={!selectedRole}
                      >
                        <option value="">Select User</option>
                        {selectedRole && getUsersByRole().length > 0 ? (
                          getUsersByRole().map((user) => (
                            <option key={user.id} value={user.id}>
                              {user.name} {user.code ? `(${user.code})` : ''}
                            </option>
                          ))
                        ) : (
                          <option value="" disabled>
                            {!selectedRole ? 'Select Role first' : 'No users available'}
                          </option>
                        )}
                      </Select>
                    </div>
                  </div>
                )}

                <div className="space-y-2">
                  <Label>Month</Label>
                  <Input
                    type="month"
                    value={targetData.month}
                    onChange={(e) => setTargetData({ ...targetData, month: e.target.value })}
                  />
                </div>

                <div className="border rounded-lg p-4">
                  <h3 className="font-semibold mb-4 text-primary">Primary Target (Purchase Amount)</h3>
                  <div className="space-y-2">
                    <Label>Purchase Amount (₹)</Label>
                    <div className="flex items-center gap-2">
                      <span className="text-gray-600">₹</span>
                        <Input
                        type="number"
                        placeholder="Enter purchase amount"
                        value={targetData.primary}
                        onChange={(e) => {
                          const value = e.target.value === '' ? '' : Math.max(0, parseFloat(e.target.value) || 0)
                          setTargetData({
                            ...targetData,
                            primary: value,
                          })
                        }}
                        onInput={(e) => {
                          if (e.target.value < 0) e.target.value = 0
                        }}
                        min="0"
                      />
                    </div>
                    <p className="text-xs text-gray-500">Total purchase amount target for this user</p>
                  </div>
                </div>

                <div className="border rounded-lg p-4">
                  <h3 className="font-semibold mb-4 text-primary">Secondary Target (Sales Amount)</h3>
                  <div className="space-y-2">
                    <Label>Sales Amount (₹)</Label>
                    <div className="flex items-center gap-2">
                      <span className="text-gray-600">₹</span>
                        <Input
                        type="number"
                        placeholder="Enter sales amount"
                        value={targetData.secondary}
                        onChange={(e) => {
                          const value = e.target.value === '' ? '' : Math.max(0, parseFloat(e.target.value) || 0)
                          setTargetData({
                            ...targetData,
                            secondary: value,
                          })
                        }}
                        onInput={(e) => {
                          if (e.target.value < 0) e.target.value = 0
                        }}
                        min="0"
                      />
                    </div>
                    <p className="text-xs text-gray-500">Total sales amount target for this user</p>
                  </div>
                </div>
              </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAssignDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleAssign} disabled={loading || !selectedRole || !selectedUserId}>
              {loading ? (editingTarget ? 'Updating...' : 'Assigning...') : (editingTarget ? 'Update Target' : 'Assign Target')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

          {successMessage && (
            <Card className="border-green-500 bg-green-50">
              <CardContent className="pt-6">
                <p className="text-green-700 font-medium">{successMessage}</p>
              </CardContent>
            </Card>
          )}

          {error && (
            <Card className="border-destructive">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <p className="text-destructive">{error}</p>
                  <Button variant="ghost" size="sm" onClick={() => dispatch(clearError())}>
                    ×
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Assigned Targets List */}
          {assignedTargets.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Assigned Targets</CardTitle>
            <CardDescription>Recently assigned targets</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {assignedTargets.map((target) => (
                <div key={target.id} className="border rounded-lg p-4">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <h4 className="font-semibold">{target.userName || 'Unknown User'}</h4>
                      <p className="text-sm text-gray-600">
                        Role: {target.role?.toUpperCase() || 'N/A'} | Month: {target.month || 'N/A'} | Assigned: {target.assignedAt ? new Date(target.assignedAt).toLocaleString() : 'Just now'}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEdit(target)}
                      >
                        Edit
                      </Button>
                      <span className="px-2 py-1 bg-green-100 text-green-800 rounded text-xs">
                        Assigned
                      </span>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 mt-3">
                    <div>
                      <h5 className="font-medium text-sm mb-2">Primary Target (Purchase)</h5>
                      <div className="space-y-1 text-sm">
                        {target.primary ? (
                          <p className="text-lg font-semibold text-primary">
                            ₹{typeof target.primary === 'string' ? parseInt(target.primary).toLocaleString('en-IN') : target.primary.toLocaleString('en-IN')}
                          </p>
                        ) : (
                          <p className="text-gray-400">No primary target</p>
                        )}
                      </div>
                    </div>
                    
                    <div>
                      <h5 className="font-medium text-sm mb-2">Secondary Target (Sales)</h5>
                      <div className="space-y-1 text-sm">
                        {target.secondary ? (
                          <p className="text-lg font-semibold text-primary">
                            ₹{typeof target.secondary === 'string' ? parseInt(target.secondary).toLocaleString('en-IN') : target.secondary.toLocaleString('en-IN')}
                          </p>
                        ) : (
                          <p className="text-gray-400">No secondary target</p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
          </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}

export default Targets
