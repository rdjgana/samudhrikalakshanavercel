import { useState, useEffect, useRef } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import {
  fetchWorkAreas,
  fetchAreaDetails,
  submitActivity,
  clearSuccessMessage,
} from '../../store/slices/activitiesSlice'
import { PURPOSE_OPTIONS, SUPERVISOR_PURPOSE_OPTIONS, ISSUE_HANDLING_CATEGORIES } from '../../data/mockData'
import { Button } from '../../components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card'
import { Input } from '../../components/ui/input'
import { Label } from '../../components/ui/label'
import { Select } from '../../components/ui/select'
import { Textarea } from '../../components/ui/textarea'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../../components/ui/table'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../../components/ui/dialog'
import { Plus, Mic, Square, Play, Pause, Trash2 } from 'lucide-react'

const Activities = () => {
  const dispatch = useDispatch()
  const { user } = useSelector((state) => state.auth)
  const { workAreas, selectedAreaDetails, submittedActivities, loading, error, successMessage } = useSelector(
    (state) => state.activities
  )

  const isSupervisor = user?.role === 'Supervisor'
  const isRSM = user?.role === 'RSM'
  const purposeOptions = isSupervisor ? SUPERVISOR_PURPOSE_OPTIONS : PURPOSE_OPTIONS

  const [formData, setFormData] = useState({
    workAreaId: '',
    purpose: '',
    reason: '',
    photos: [],
    completionStatus: '', // For Primary Sale and Secondary Sales
    notCompletedReason: '', // Reason if not completed
    issueCategory: '', // For Issue Handling
    voiceOfMarket: '', // For Voice of Market
    voiceRecording: null, // For Voice Report recording
  })
  const [location, setLocation] = useState({ latitude: null, longitude: null })
  const [showFormDialog, setShowFormDialog] = useState(false)
  
  // Voice recording states
  const [isRecording, setIsRecording] = useState(false)
  const [isPaused, setIsPaused] = useState(false)
  const [recordingTime, setRecordingTime] = useState(0)
  const [audioURL, setAudioURL] = useState(null)
  const [isPlaying, setIsPlaying] = useState(false)
  
  const mediaRecorderRef = useRef(null)
  const audioChunksRef = useRef([])
  const timerRef = useRef(null)
  const audioRef = useRef(null)

  useEffect(() => {
    dispatch(fetchWorkAreas())
    getCurrentLocation()
  }, [dispatch])

  useEffect(() => {
    if (formData.workAreaId) {
      dispatch(fetchAreaDetails(formData.workAreaId))
    }
  }, [formData.workAreaId, dispatch])

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current)
      }
      if (audioURL) {
        URL.revokeObjectURL(audioURL)
      }
      if (mediaRecorderRef.current && isRecording) {
        mediaRecorderRef.current.stop()
      }
    }
  }, [audioURL, isRecording])

  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
          })
        },
        (error) => {
          console.error('Geolocation error:', error)
        }
      )
    }
  }

  // Voice Recording Functions
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const mediaRecorder = new MediaRecorder(stream)
      mediaRecorderRef.current = mediaRecorder
      audioChunksRef.current = []

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data)
        }
      }

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' })
        const url = URL.createObjectURL(audioBlob)
        setAudioURL(url)
        setFormData({ ...formData, voiceRecording: audioBlob })
        
        // Stop all tracks
        stream.getTracks().forEach(track => track.stop())
      }

      mediaRecorder.start()
      setIsRecording(true)
      setIsPaused(false)
      setRecordingTime(0)

      // Start timer
      timerRef.current = setInterval(() => {
        setRecordingTime((prev) => prev + 1)
      }, 1000)
    } catch (error) {
      console.error('Error accessing microphone:', error)
      alert('Unable to access microphone. Please grant permission.')
    }
  }

  const pauseRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      if (isPaused) {
        mediaRecorderRef.current.resume()
        setIsPaused(false)
        timerRef.current = setInterval(() => {
          setRecordingTime((prev) => prev + 1)
        }, 1000)
      } else {
        mediaRecorderRef.current.pause()
        setIsPaused(true)
        clearInterval(timerRef.current)
      }
    }
  }

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop()
      setIsRecording(false)
      setIsPaused(false)
      clearInterval(timerRef.current)
    }
  }

  const deleteRecording = () => {
    if (audioURL) {
      URL.revokeObjectURL(audioURL)
    }
    setAudioURL(null)
    setFormData({ ...formData, voiceRecording: null })
    setRecordingTime(0)
    setIsPlaying(false)
  }

  const togglePlayPause = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause()
        setIsPlaying(false)
      } else {
        audioRef.current.play()
        setIsPlaying(true)
      }
    }
  }

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
  }

  const handleFileChange = (e) => {
    const files = Array.from(e.target.files)
    setFormData({ ...formData, photos: files })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    
    // Validation
    if (!formData.workAreaId || !formData.purpose || !formData.reason || formData.photos.length === 0) {
      alert('Please fill all required fields and upload at least one photo')
      return
    }

    // Supervisor-specific validations
    if (isSupervisor) {
      // For Primary Sale and Secondary Sales, completion status is required
      if ((formData.purpose === 'Primary Sale' || formData.purpose === 'Secondary Sales') && !formData.completionStatus) {
        alert('Please select completion status')
        return
      }

      // If not completed, reason is required
      if (formData.completionStatus === 'Not Completed' && !formData.notCompletedReason) {
        alert('Please provide reason for not completing the activity')
        return
      }

      // For Issue Handling, category is required
      if (formData.purpose === 'Issue Handling' && !formData.issueCategory) {
        alert('Please select issue handling category')
        return
      }
    }

    const result = await dispatch(
      submitActivity({
        ...formData,
        latitude: location.latitude,
        longitude: location.longitude,
      })
    )

    if (submitActivity.fulfilled.match(result)) {
      // Cleanup audio recording
      if (audioURL) {
        URL.revokeObjectURL(audioURL)
      }
      
      // Reset form
      setFormData({
        workAreaId: '',
        purpose: '',
        reason: '',
        photos: [],
        completionStatus: '',
        notCompletedReason: '',
        issueCategory: '',
        voiceOfMarket: '',
        voiceRecording: null,
      })
      
      // Reset audio states
      setAudioURL(null)
      setRecordingTime(0)
      setIsPlaying(false)
      setIsRecording(false)
      setIsPaused(false)
      
      // Close dialog for RSM and Supervisor roles
      if (isRSM || isSupervisor) {
        setShowFormDialog(false)
      }
      
      // Clear success message after 5 seconds
      setTimeout(() => {
        dispatch(clearSuccessMessage())
      }, 5000)
    }
  }

  // Render the activity form
  const renderActivityForm = () => (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="workArea">Work Area *</Label>
        <Select
          id="workArea"
          value={formData.workAreaId}
          onChange={(e) => {
            setFormData({ ...formData, workAreaId: e.target.value })
            if (e.target.value) {
              dispatch(fetchAreaDetails(e.target.value))
            }
          }}
          required
        >
          <option value="">Select Work Area (Tamil Nadu District)</option>
          {workAreas.length > 0 ? (
            workAreas.map((area) => (
              <option key={area.id} value={area.id}>
                {area.name}
              </option>
            ))
          ) : (
            <option value="" disabled>Loading districts...</option>
          )}
        </Select>
      </div>

      {selectedAreaDetails && (
        <Card className="bg-gray-50">
          <CardContent className="pt-6">
            <h3 className="font-semibold mb-2">Area Details:</h3>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-sm">
              {selectedAreaDetails.asm && (
                <div>
                  <p className="text-gray-600">ASM:</p>
                  <p className="font-medium">{selectedAreaDetails.asm}</p>
                </div>
              )}
              {selectedAreaDetails.so && (
                <div>
                  <p className="text-gray-600">SO:</p>
                  <p className="font-medium">{selectedAreaDetails.so}</p>
                </div>
              )}
              {selectedAreaDetails.supervisor && (
                <div>
                  <p className="text-gray-600">Supervisor:</p>
                  <p className="font-medium">{selectedAreaDetails.supervisor}</p>
                </div>
              )}
              {selectedAreaDetails.distributor && (
                <div>
                  <p className="text-gray-600">Distributor:</p>
                  <p className="font-medium">{selectedAreaDetails.distributor}</p>
                </div>
              )}
              {selectedAreaDetails.ss && (
                <div>
                  <p className="text-gray-600">SS:</p>
                  <p className="font-medium">{selectedAreaDetails.ss}</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="space-y-2">
        <Label htmlFor="purpose">Purpose of Visit *</Label>
        <Select
          id="purpose"
          value={formData.purpose}
          onChange={(e) => {
            setFormData({ 
              ...formData, 
              purpose: e.target.value,
              completionStatus: '', // Reset when purpose changes
              issueCategory: '', // Reset when purpose changes
            })
          }}
          required
        >
          <option value="">Select Purpose</option>
          {purposeOptions.map((purpose) => (
            <option key={purpose} value={purpose}>
              {purpose}
            </option>
          ))}
        </Select>
      </div>

      {/* Completion Status for Primary Sale and Secondary Sales (Supervisor only) */}
      {isSupervisor && (formData.purpose === 'Primary Sale' || formData.purpose === 'Secondary Sales') && (
        <div className="space-y-2">
          <Label>Completion Status *</Label>
          <div className="flex gap-4">
            <label className="flex items-center space-x-2">
              <input
                type="radio"
                name="completionStatus"
                value="Completed"
                checked={formData.completionStatus === 'Completed'}
                onChange={(e) => setFormData({ ...formData, completionStatus: e.target.value, notCompletedReason: '' })}
                required
              />
              <span>Completed</span>
            </label>
            <label className="flex items-center space-x-2">
              <input
                type="radio"
                name="completionStatus"
                value="Not Completed"
                checked={formData.completionStatus === 'Not Completed'}
                onChange={(e) => setFormData({ ...formData, completionStatus: e.target.value })}
                required
              />
              <span>Not Completed</span>
            </label>
          </div>
        </div>
      )}

      {/* Reason for Not Completed (Supervisor only) */}
      {isSupervisor && formData.completionStatus === 'Not Completed' && (
        <div className="space-y-2">
          <Label htmlFor="notCompletedReason">Reason for Not Completing *</Label>
          <Textarea
            id="notCompletedReason"
            placeholder="Enter reason why the activity was not completed"
            value={formData.notCompletedReason}
            onChange={(e) => setFormData({ ...formData, notCompletedReason: e.target.value })}
            required
            rows={3}
          />
        </div>
      )}

      {/* Issue Handling Category (Supervisor only) */}
      {isSupervisor && formData.purpose === 'Issue Handling' && (
        <div className="space-y-2">
          <Label htmlFor="issueCategory">Issue Handling Category *</Label>
          <Select
            id="issueCategory"
            value={formData.issueCategory}
            onChange={(e) => setFormData({ ...formData, issueCategory: e.target.value })}
            required
          >
            <option value="">Select Category</option>
            {ISSUE_HANDLING_CATEGORIES.map((category) => (
              <option key={category} value={category}>
                {category}
              </option>
            ))}
          </Select>
        </div>
      )}

      {/* Voice of Market (Supervisor only - End of Day) */}
      {isSupervisor && formData.purpose === 'Voice of Market' && (
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="voiceOfMarket">Voice of Market (End of Day Recording) *</Label>
            <Textarea
              id="voiceOfMarket"
              placeholder="Record voice of market feedback..."
              value={formData.voiceOfMarket}
              onChange={(e) => setFormData({ ...formData, voiceOfMarket: e.target.value })}
              required
              rows={5}
            />
            <p className="text-xs text-gray-500">This should be recorded at the end of the day</p>
          </div>

          {/* Voice Recording Section */}
          <div className="space-y-2">
            <Label>Voice Recording (Optional)</Label>
            <Card className="bg-gray-50 border-2 border-dashed">
              <CardContent className="pt-6">
                {!audioURL ? (
                  <div className="space-y-4">
                    {!isRecording ? (
                      <Button
                        type="button"
                        onClick={startRecording}
                        className="w-full bg-red-600 hover:bg-red-700 text-white"
                      >
                        <Mic className="h-4 w-4 mr-2" />
                        Start Recording
                      </Button>
                    ) : (
                      <div className="space-y-3">
                        <div className="flex items-center justify-center space-x-2">
                          <div className={`h-3 w-3 rounded-full ${isPaused ? 'bg-yellow-500' : 'bg-red-500 animate-pulse'}`}></div>
                          <span className="text-lg font-mono font-semibold">{formatTime(recordingTime)}</span>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            type="button"
                            onClick={pauseRecording}
                            className="flex-1 bg-yellow-600 hover:bg-yellow-700 text-white"
                          >
                            {isPaused ? (
                              <>
                                <Play className="h-4 w-4 mr-2" />
                                Resume
                              </>
                            ) : (
                              <>
                                <Pause className="h-4 w-4 mr-2" />
                                Pause
                              </>
                            )}
                          </Button>
                          <Button
                            type="button"
                            onClick={stopRecording}
                            className="flex-1 bg-gray-600 hover:bg-gray-700 text-white"
                          >
                            <Square className="h-4 w-4 mr-2" />
                            Stop
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 bg-white rounded-lg border">
                      <div className="flex items-center space-x-3">
                        <Button
                          type="button"
                          onClick={togglePlayPause}
                          size="sm"
                          className="bg-blue-600 hover:bg-blue-700 text-white"
                        >
                          {isPlaying ? (
                            <Pause className="h-4 w-4" />
                          ) : (
                            <Play className="h-4 w-4" />
                          )}
                        </Button>
                        <div className="flex flex-col">
                          <span className="text-sm font-medium">Voice Recording</span>
                          <span className="text-xs text-gray-500">{formatTime(recordingTime)}</span>
                        </div>
                      </div>
                      <Button
                        type="button"
                        onClick={deleteRecording}
                        size="sm"
                        variant="destructive"
                        className="bg-red-600 hover:bg-red-700"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                    <audio
                      ref={audioRef}
                      src={audioURL}
                      onEnded={() => setIsPlaying(false)}
                      className="hidden"
                    />
                    <Button
                      type="button"
                      onClick={() => {
                        deleteRecording()
                      }}
                      variant="outline"
                      className="w-full"
                    >
                      Record Again
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {/* Voice Report Recording (for other roles if needed) */}
      {!isSupervisor && formData.purpose === 'Voice Report' && (
        <div className="space-y-2">
          <Label>Voice Report Recording *</Label>
          <Card className="bg-gray-50 border-2 border-dashed">
            <CardContent className="pt-6">
              {!audioURL ? (
                <div className="space-y-4">
                  {!isRecording ? (
                    <Button
                      type="button"
                      onClick={startRecording}
                      className="w-full bg-red-600 hover:bg-red-700 text-white"
                    >
                      <Mic className="h-4 w-4 mr-2" />
                      Start Recording
                    </Button>
                  ) : (
                    <div className="space-y-3">
                      <div className="flex items-center justify-center space-x-2">
                        <div className={`h-3 w-3 rounded-full ${isPaused ? 'bg-yellow-500' : 'bg-red-500 animate-pulse'}`}></div>
                        <span className="text-lg font-mono font-semibold">{formatTime(recordingTime)}</span>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          type="button"
                          onClick={pauseRecording}
                          className="flex-1 bg-yellow-600 hover:bg-yellow-700 text-white"
                        >
                          {isPaused ? (
                            <>
                              <Play className="h-4 w-4 mr-2" />
                              Resume
                            </>
                          ) : (
                            <>
                              <Pause className="h-4 w-4 mr-2" />
                              Pause
                            </>
                          )}
                        </Button>
                        <Button
                          type="button"
                          onClick={stopRecording}
                          className="flex-1 bg-gray-600 hover:bg-gray-700 text-white"
                        >
                          <Square className="h-4 w-4 mr-2" />
                          Stop
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-white rounded-lg border">
                    <div className="flex items-center space-x-3">
                      <Button
                        type="button"
                        onClick={togglePlayPause}
                        size="sm"
                        className="bg-blue-600 hover:bg-blue-700 text-white"
                      >
                        {isPlaying ? (
                          <Pause className="h-4 w-4" />
                        ) : (
                          <Play className="h-4 w-4" />
                        )}
                      </Button>
                      <div className="flex flex-col">
                        <span className="text-sm font-medium">Voice Recording</span>
                        <span className="text-xs text-gray-500">{formatTime(recordingTime)}</span>
                      </div>
                    </div>
                    <Button
                      type="button"
                      onClick={deleteRecording}
                      size="sm"
                      variant="destructive"
                      className="bg-red-600 hover:bg-red-700"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                  <audio
                    ref={audioRef}
                    src={audioURL}
                    onEnded={() => setIsPlaying(false)}
                    className="hidden"
                  />
                  <Button
                    type="button"
                    onClick={() => {
                      deleteRecording()
                    }}
                    variant="outline"
                    className="w-full"
                  >
                    Record Again
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      <div className="space-y-2">
        <Label htmlFor="reason">Reason *</Label>
        <Textarea
          id="reason"
          placeholder="Enter specific reason for this visit"
          value={formData.reason}
          onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
          required
          rows={4}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="photos">Upload Photos *</Label>
        <Input
          id="photos"
          type="file"
          accept="image/*"
          multiple
          onChange={handleFileChange}
          required
        />
        {formData.photos.length > 0 && (
          <p className="text-sm text-gray-600">
            {formData.photos.length} photo(s) selected
          </p>
        )}
      </div>

      {location.latitude && location.longitude && (
        <div className="text-sm text-gray-600">
          GPS Location: {location.latitude.toFixed(6)}, {location.longitude.toFixed(6)}
        </div>
      )}

      {error && (
        <div className="text-sm text-destructive bg-destructive/10 p-3 rounded-md">
          {error}
        </div>
      )}

      {successMessage && (
        <div className="text-sm text-green-700 bg-green-50 p-3 rounded-md">
          {successMessage}
        </div>
      )}

      <Button type="submit" className="w-full bg-[#433228] hover:bg-[#5a4238] text-white" disabled={loading}>
        {loading ? 'Submitting...' : 'Submit Activity'}
      </Button>
    </form>
  )

  return (
    <div className="space-y-6">
      {/* Header with Add Button for RSM and Supervisor */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">My Activities</h1>
          <p className="text-gray-600 mt-2">Record your field visits and activities</p>
        </div>
        {(isRSM || isSupervisor) && (
          <Button
            onClick={() => setShowFormDialog(true)}
            className="bg-[#433228] hover:bg-[#5a4238] text-white"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Activity
          </Button>
        )}
      </div>

      {/* Submitted Activities List - Always shown by default */}
      <Card>
        <CardHeader>
            <CardTitle>Submitted Activities</CardTitle>
            <CardDescription>List of all submitted activities</CardDescription>
          </CardHeader>
          <CardContent>
            {submittedActivities.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>S.No</TableHead>
                    <TableHead>Date & Time</TableHead>
                    <TableHead>Work Area</TableHead>
                    <TableHead>Purpose</TableHead>
                    <TableHead>Reason</TableHead>
                    {isSupervisor && <TableHead>Status</TableHead>}
                    {isSupervisor && <TableHead>Category</TableHead>}
                    <TableHead>GPS Location</TableHead>
                    <TableHead>Photos</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {submittedActivities.map((activity, index) => (
                    <TableRow key={activity.id}>
                      <TableCell className="font-medium">{index + 1}</TableCell>
                      <TableCell>
                        {new Date(activity.submittedAt).toLocaleString()}
                      </TableCell>
                      <TableCell className="font-medium">{activity.workAreaName}</TableCell>
                      <TableCell>{activity.purpose}</TableCell>
                      <TableCell className="max-w-xs truncate">{activity.reason}</TableCell>
                      {isSupervisor && (
                        <TableCell>
                          {activity.completionStatus ? (
                            <span className={`px-2 py-1 rounded text-xs ${
                              activity.completionStatus === 'Completed' 
                                ? 'bg-green-100 text-green-800' 
                                : 'bg-red-100 text-red-800'
                            }`}>
                              {activity.completionStatus}
                            </span>
                          ) : (
                            <span className="text-gray-400">N/A</span>
                          )}
                        </TableCell>
                      )}
                      {isSupervisor && (
                        <TableCell>
                          {activity.issueCategory || activity.voiceOfMarket ? (
                            <span className="text-sm">{activity.issueCategory || 'Voice of Market'}</span>
                          ) : (
                            <span className="text-gray-400">N/A</span>
                          )}
                        </TableCell>
                      )}
                      <TableCell className="text-xs">
                        {activity.latitude && activity.longitude ? (
                          <span>
                            {activity.latitude.toFixed(4)}, {activity.longitude.toFixed(4)}
                          </span>
                        ) : (
                          <span className="text-gray-400">N/A</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <span className="text-sm">{activity.photoCount} photo(s)</span>
                      </TableCell>
                      <TableCell>
                        <span className="px-2 py-1 rounded-full text-xs bg-green-100 text-green-800">
                          {activity.status}
                        </span>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <p className="text-center text-gray-500 py-8">No activities submitted yet</p>
            )}
          </CardContent>
        </Card>

      {/* Form Dialog for RSM and Supervisor */}
      {(isRSM || isSupervisor) && (
        <Dialog open={showFormDialog} onOpenChange={setShowFormDialog}>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>New Activity</DialogTitle>
              <DialogDescription>GPS-based work area selection and activity reporting</DialogDescription>
            </DialogHeader>
            {renderActivityForm()}
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}

export default Activities
