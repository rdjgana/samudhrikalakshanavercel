import { Routes, Route, Navigate } from 'react-router-dom'
import { useSelector } from 'react-redux'
import Login from './pages/auth/Login'
import MainLayout from './components/layout/MainLayout'
import Dashboard from './pages/dashboard/Dashboard'
import SupervisorDashboard from './pages/supervisor/SupervisorDashboard'
import SalesReport from './pages/supervisor/SalesReport'
import WorkPlan from './pages/supervisor/WorkPlan'
import SalaryExpenses from './pages/supervisor/SalaryExpenses'
import Profile from './pages/supervisor/Profile'
import PromoterDashboard from './pages/promoter/PromoterDashboard'
import PromoterTasks from './pages/promoter/PromoterTasks'
import PromoterSalesReport from './pages/promoter/PromoterSalesReport'
import PromoterSalesReturn from './pages/promoter/PromoterSalesReturn'
import PromoterIncentive from './pages/promoter/PromoterIncentive'
import PromoterReports from './pages/promoter/PromoterReports'
import PromoterTrainingMaterial from './pages/promoter/PromoterTrainingMaterial'
import PromoterCustomerFeedback from './pages/promoter/PromoterCustomerFeedback'
import PromoterProfile from './pages/promoter/PromoterProfile'
import SuperStockistDashboard from './pages/super-stockist/SuperStockistDashboard'
import SuperStockistProfile from './pages/super-stockist/SuperStockistProfile'
import SuperStockistOrders from './pages/super-stockist/SuperStockistOrders'
import SuperStockistStock from './pages/super-stockist/SuperStockistStock'
import SuperStockistReports from './pages/super-stockist/SuperStockistReports'
import SuperStockistClaims from './pages/super-stockist/SuperStockistClaims'
import SuperStockistShipment from './pages/super-stockist/SuperStockistShipment'
import DistributorDashboard from './pages/distributor/DistributorDashboard'
import DistributorProfile from './pages/distributor/DistributorProfile'
import DistributorOrders from './pages/distributor/DistributorOrders'
import DistributorStock from './pages/distributor/DistributorStock'
import DistributorReports from './pages/distributor/DistributorReports'
import DistributorClaims from './pages/distributor/DistributorClaims'
import DistributorBillsReceivable from './pages/distributor/DistributorBillsReceivable'
import DistributorConsignment from './pages/distributor/DistributorConsignment'
import TrainingMaterial from './pages/training/TrainingMaterial'
import Attendance from './pages/attendance/Attendance'
import Activities from './pages/activities/Activities'
import Targets from './pages/targets/Targets'
import Orders from './pages/orders/Orders'
import Manpower from './pages/manpower/Manpower'
import Claims from './pages/claims/Claims'
import Reports from './pages/reports/Reports'
import Approvals from './pages/approvals/Approvals'
import UserProfile from './pages/profile/Profile'
import ProtectedRoute from './components/auth/ProtectedRoute'

function App() {
  const { user } = useSelector((state) => state.auth)
  const isSupervisor = user?.role === 'Supervisor'
  const isPromoter = user?.role === 'Promoter'
  const isSuperStockist = user?.role === 'Super Stockist'
  const isDistributor = user?.role === 'Distributor'

  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route
        path="/*"
        element={
          <ProtectedRoute>
            <MainLayout>
              <Routes>
                <Route 
                  path="/" 
                  element={
                    isPromoter
                      ? <Navigate to="/promoter/dashboard" replace />
                      : isSupervisor 
                      ? <Navigate to="/supervisor/dashboard" replace />
                      : isSuperStockist
                      ? <Navigate to="/super-stockist/dashboard" replace />
                      : isDistributor
                      ? <Navigate to="/distributor/dashboard" replace />
                      : <Navigate to="/dashboard" replace />
                  } 
                />
                <Route path="/dashboard" element={<Dashboard />} />
                <Route path="/supervisor/dashboard" element={<SupervisorDashboard />} />
                <Route path="/supervisor/sales-report" element={<SalesReport />} />
                <Route path="/supervisor/work-plan" element={<WorkPlan />} />
                <Route path="/supervisor/salary-expenses" element={<SalaryExpenses />} />
                <Route path="/supervisor/profile" element={<Profile />} />
                <Route path="/promoter/dashboard" element={<PromoterDashboard />} />
                <Route path="/promoter/tasks" element={<PromoterTasks />} />
                <Route path="/promoter/sales-report" element={<PromoterSalesReport />} />
                <Route path="/promoter/sales-return" element={<PromoterSalesReturn />} />
                <Route path="/promoter/incentive" element={<PromoterIncentive />} />
                <Route path="/promoter/reports" element={<PromoterReports />} />
                <Route path="/promoter/training-material" element={<PromoterTrainingMaterial />} />
                <Route path="/promoter/customer-feedback" element={<PromoterCustomerFeedback />} />
                <Route path="/promoter/profile" element={<PromoterProfile />} />
                <Route path="/super-stockist/dashboard" element={<SuperStockistDashboard />} />
                <Route path="/super-stockist/profile" element={<SuperStockistProfile />} />
                <Route path="/super-stockist/orders" element={<SuperStockistOrders />} />
                <Route path="/super-stockist/stock" element={<SuperStockistStock />} />
                <Route path="/super-stockist/reports" element={<SuperStockistReports />} />
                <Route path="/super-stockist/claims" element={<SuperStockistClaims />} />
                <Route path="/super-stockist/shipment" element={<SuperStockistShipment />} />
                <Route path="/distributor/dashboard" element={<DistributorDashboard />} />
                <Route path="/distributor/profile" element={<DistributorProfile />} />
                <Route path="/distributor/orders" element={<DistributorOrders />} />
                <Route path="/distributor/stock" element={<DistributorStock />} />
                <Route path="/distributor/reports" element={<DistributorReports />} />
                <Route path="/distributor/claims" element={<DistributorClaims />} />
                <Route path="/distributor/bills-receivable" element={<DistributorBillsReceivable />} />
                <Route path="/distributor/consignment" element={<DistributorConsignment />} />
                <Route path="/attendance" element={<Attendance />} />
                <Route path="/activities" element={<Activities />} />
                <Route path="/targets" element={<Targets />} />
                <Route path="/orders" element={<Orders />} />
                <Route path="/manpower" element={<Manpower />} />
                <Route path="/claims" element={<Claims />} />
                <Route path="/reports" element={<Reports />} />
                <Route path="/approvals" element={<Approvals />} />
                <Route path="/training-material" element={<TrainingMaterial />} />
                <Route path="/profile" element={<UserProfile />} />
              </Routes>
            </MainLayout>
          </ProtectedRoute>
        }
      />
    </Routes>
  )
}

export default App
